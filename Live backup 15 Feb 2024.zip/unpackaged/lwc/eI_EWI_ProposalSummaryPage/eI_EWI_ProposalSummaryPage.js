import { LightningElement ,track,wire, api} from 'lwc';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { getRecord } from 'lightning/uiRecordApi';
import getCaseParticipantDetails from "@salesforce/apex/EI_EWI_ProposalSummaryClass.getCaseParticipantDetails";
import getCaseandDispiteItemsDetails from '@salesforce/apex/EI_EWI_ProposalSummaryClass.getCaseandDispiteItemsDetails';
import updateTenantfundstatus from '@salesforce/apex/EI_EWI_ProposalSummaryClass.updateTenantfundstatus';
import getPaymentMethod from '@salesforce/apex/EWI_PayDisputedFundsController.getPaymentMethod';
import setDisputedAmount from '@salesforce/apex/EWI_PayDisputedFundsController.setDisputedAmount';
import getCaseCurrentDetails from "@salesforce/apex/EI_EWI_ProposalSummaryClass.getCaseCurrentDetails"

export default class EI_EWI_ProposalSummaryPage extends NavigationMixin (LightningElement) {
    ew_arrow_dropleft = EWITheme + '/assets/img/ew-arrow-dropleft.png';
    @track caseParticipant;
    @track accessCode;
    @track leadTenant;
    @track disputeItems = [];
    @track disputeItemsStatic = [];
    @track otherDisputeReason;
    @track agllName;
    @track error;
    @api recordId;
    @track status;
    @track text_Agll_New=false;
    @track text_Tenant_New=false;
    // @track text_Agll_ProposalsubmittedAGLL = false;
    @track text_AgllNonMember_ProposalsubmittedAGLL = false;
    @track text_NonMember_ProposalsubmittedAGll = false;
    @track text_AGLL_ProposalsubmittedNonMember = false;
    @track text_LeadTenant_Proposalsubmittedtenant=false;
    @track text_JointTenant_Proposalsubmittedtenant = false;
    @track text_Tenant_AwaitingTenantResponse = false;
    @track text_AgLL_AwaitingAGLLResponse =false;
    @track caseStatus;
    @track status;
    @track containsleadtenant = false;
    @track isCaseLead;
    @track caseParticipantType;
    @track depositEndDate;
    @track depositAmount;
    @track initialAmountToTenant;
    @track initialAmountToAGLL;
    @track isShowDepositSummary = false;
    @track isShowReviewProposalSummary = false;
    @track propertyaddress;
    @track text_LeadTenant_EvidencegatheringAGLL = false;
    @track text_JointTenant_EvidencegatheringAGLL = false;
    @track text_LeadTenant_EvidencegatheringTenant = false;
    @track text_JointTenant_EvidencegatheringTenant = false;
    @track text_AGLL_EvidencegatheringTenant = false;
    @track text_AGLL_SubmitEvidence = false;
    @track caseRespondDate;
    @track case_Dispute_resolution_status = '';
    @track AGLL_Raised_Respond;
    @track text_Case_SelfResolutionTT = false; 
    @track text_Case_SelfResolutionAGLL = false;
    @track claimexceedamount = 0.00;
    paymentMethod;
    disputedFundsReceived;
    caseParticipantType;
    isPrimaryAgent;

    get isReviewProposalAGLL(){
        if((this.caseStatus == 'Proposal submitted – awaiting agent/landlord response' || 
            this.caseStatus == 'Proposal submitted – agent/landlord' || 
            this.caseStatus == 'Proposal submitted – awaiting tenant response')
        && (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord' || this.caseParticipantType=='Non-Member Landlord'))
            return true;
        else 
            return false;
    }
    get isReviewProposalTT(){
        if(this.caseStatus == 'Proposal submitted – awaiting tenant response' && this.caseParticipantType=='Tenant') //  && this.isCaseLead == true
            return true;
        else 
            return false;
    }

    get isNewProposalAGLL(){
        if(this.caseStatus == 'New' && (this.caseParticipantType=='Non-Member Landlord' ||
        this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord')
        && this.AGLL_Raised_Respond == true)
            return true;
        else 
            return false;
    }
    get isSelfResultionProposal(){
        if(this.caseStatus == 'Self-resolution' && this.caseParticipantType!='Tenant' && this.AGLL_Raised_Respond ==true)
            return true;
        else 
            return false;
    }

    get isSelfResultionProposalviewonly(){
        if((this.caseStatus == 'Self-resolution' && this.caseParticipantType!='Tenant' && this.AGLL_Raised_Respond ==false)
        || (this.caseStatus == 'Self-resolution - awaiting review' && this.caseParticipantType!='Tenant') )
            return true;
        else 
            return false;
    }



    get isSelfResultionProposaltoleadtt(){
        if(this.caseStatus == 'Self-resolution' && this.caseParticipantType=='Tenant' && this.isCaseLead == true)
            return true;
        else 
            return false;
    }

    get isSelfResultionProposaltojointtt(){
        if((this.caseStatus == 'Self-resolution' && this.caseParticipantType=='Tenant' && this.isCaseLead == false)
        || (this.caseStatus == 'Self-resolution - awaiting review' && this.caseParticipantType=='Tenant') )
            return true;
        else 
            return false;
    }

    //EID 25 start
    get isShowSubmitEvidenceAGLL(){
        if(this.caseStatus == 'Evidence gathering agent/landlord' && (this.caseParticipantType=='Non-Member Landlord' ||
        this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord')
        && this.caseParticipant.Case__r.AGLL_Respond_Evidance_Gathering__c == false
        && this.AGLL_Raised_Respond == true)
            return true;
        else 
            return false;
    }
    get isShowReviewEditEvidenceAGLL(){
        if(this.caseStatus == 'Evidence gathering agent/landlord' && (this.caseParticipantType=='Non-Member Landlord' ||
        this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord')
        && this.caseParticipant.Case__r.AGLL_Respond_Evidance_Gathering__c == true
        && this.AGLL_Raised_Respond == true)
            return true;
        else 
            return false;
    }

    get isShowDisputedAmount(){
        //if(this.caseStatus == 'Evidence gathering agent/landlord' && (this.paymentMethod == null || this.paymentMethod == undefined))
        if((this.caseStatus == 'Evidence gathering agent/landlord' || this.caseStatus == 'Evidence gathering tenant' || this.caseStatus == 'Awaiting Review' || this.caseStatus == 'Evidence review complete' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Deposit to be repaid - decision issued' || this.caseStatus == 'Decision issued - dispute monies outstanding' || this.caseStatus == 'Decision issued - Insurance claim' || this.caseStatus == 'Decision issued - with legal' || this.caseStatus == 'Deposit to be repaid - resolved without adjudication' || this.caseStatus == 'On Hold') && (this.paymentMethod == null || this.paymentMethod == undefined))
            return true;
        //else if(this.caseStatus == 'Evidence gathering agent/landlord' && (this.paymentMethod.Payment_Method__c == null || this.paymentMethod.Payment_Method__c == undefined ))
        else if((this.caseStatus == 'Evidence gathering agent/landlord' || this.caseStatus == 'Evidence gathering tenant' || this.caseStatus == 'Awaiting Review' || this.caseStatus == 'Evidence review complete' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Deposit to be repaid - decision issued' || this.caseStatus == 'Decision issued - dispute monies outstanding' || this.caseStatus == 'Decision issued - Insurance claim' || this.caseStatus == 'Decision issued - with legal' || this.caseStatus == 'Deposit to be repaid - resolved without adjudication' || this.caseStatus == 'On Hold') && (this.paymentMethod.Payment_Method__c == null || this.paymentMethod.Payment_Method__c == undefined ))
            return true;
        else 
            return false;
    }
    get isshowPaymentButton(){
        //if(this.caseStatus == 'Evidence gathering agent/landlord' && (this.paymentMethod != null || this.paymentMethod != undefined) && (this.paymentMethod.Status__c == 'Collected'))
        if((this.caseStatus == 'Evidence gathering agent/landlord' || this.caseStatus == 'Evidence gathering tenant' || this.caseStatus == 'Awaiting Review' || this.caseStatus == 'Evidence review complete' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Deposit to be repaid - decision issued' || this.caseStatus == 'Decision issued - dispute monies outstanding' || this.caseStatus == 'Decision issued - Insurance claim' || this.caseStatus == 'Decision issued - with legal' || this.caseStatus == 'Deposit to be repaid - resolved without adjudication' || this.caseStatus == 'On Hold') && (this.paymentMethod != null || this.paymentMethod != undefined) && (this.paymentMethod.Status__c == 'Collected'))
            return true;
        else
            return false;
    }
    get isshowPayDisputedButton(){
        console.log('Participatnt Type 3'+ this.caseParticipantType + this.disputedFundsReceived );
        //if(this.disputedFundsReceived || !((this.caseParticipantType == 'Agent' && this.isPrimaryAgent) || this.caseParticipantType == 'Independent-Landlord') || !(this.caseStatus == 'Evidence gathering agent/landlord'))
        //if(this.disputedFundsReceived || !((this.caseParticipantType == 'Agent') || this.caseParticipantType == 'Independent-Landlord') || !(this.caseStatus == 'Evidence gathering agent/landlord'))
        if(this.disputedFundsReceived || !((this.caseParticipantType == 'Agent') || this.caseParticipantType == 'Independent-Landlord') || !(this.caseStatus == 'Evidence gathering agent/landlord' || this.caseStatus == 'Evidence gathering tenant' || this.caseStatus == 'Awaiting Review' || this.caseStatus == 'Evidence review complete' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Adjudication' || this.caseStatus == 'Deposit to be repaid - decision issued' || this.caseStatus == 'Decision issued - dispute monies outstanding' || this.caseStatus == 'Decision issued - Insurance claim' || this.caseStatus == 'Decision issued - with legal' || this.caseStatus == 'Deposit to be repaid - resolved without adjudication' || this.caseStatus == 'On Hold'))
            {
                return false;
            }
        else
        {
            return true;
        }
    }

    get isShowReviewEvidence_JointTTandAGLL(){
        if(this.caseStatus == 'Evidence gathering tenant' &&
        (this.caseParticipantType=='Non-Member Landlord' || this.caseParticipantType=='Agent' 
        || this.caseParticipantType=='Independent-Landlord' 
        || (this.caseParticipantType=='Tenant' && this.isCaseLead == false && this.containsleadtenant == true) )
        && this.caseParticipant.Case__r.AGLL_Respond_Evidance_Gathering__c == true)
            return true;
        else 
            return false;
    }
    // eid 25 end

    //EID 26 start
    get isShowSubmitEvidenceTT(){
        if(this.caseStatus == 'Evidence gathering tenant' && this.caseParticipantType=='Tenant' && ((this.isCaseLead == true && this.containsleadtenant == true)|| (this.isCaseLead == false && this.containsleadtenant == false))
        && this.caseParticipant.Case__r.TT_respond_evidence_gathering__c == false)
            return true;
        else 
            return false;
    }
    get isShowReviewEditEvidenceLeadTT(){
        if(this.caseStatus == 'Evidence gathering tenant' && this.caseParticipantType=='Tenant' && this.isCaseLead== true
        && this.caseParticipant.Case__r.TT_respond_evidence_gathering__c == true)
            return true;
        else 
            return false;
    }
    get isShowReviewEvidence_TTandAGLL(){
        if((this.caseParticipant.Case__r.TT_respond_evidence_gathering__c == true || 
            this.caseParticipant.Case__r.AGLL_Respond_Evidance_Gathering__c == true ||
            this.caseParticipant.Case__r.No_of_AGLL_evidences__c > 0 ||
            this.caseParticipant.Case__r.No_of_tenant_evidence__c > 0) &&
            (this.caseStatus == 'Awaiting Review' 
            || this.caseStatus == 'Evidence review complete'
            || this.caseStatus == 'Adjudication'
            || this.caseStatus == 'Case closed – resolved without adjudication'
            || this.caseStatus == 'Deposit to be repaid - resolved without adjudication'
            || this.caseStatus == 'Deposit to be repaid - decision issued'
            || this.caseStatus == 'Deposit closed - deposit repaid in full'
            || this.caseStatus == 'Deposit closed - deposit repaid in part'
            || this.caseStatus == 'Deposit closed - unable to repay'
            || this.caseStatus == 'On Hold'
            || this.caseStatus == 'Rejected'))
            return true;
        else 
            return false;
    }
    // eid 26 end

    // get isShowLeadTenantName(){
    //     if((this.caseStatus == 'New' && this.caseParticipantType=='Tenant') || this.caseStatus == 'Proposal submitted- tenant'
    //     || this.caseStatus == 'Proposal submitted – awaiting agent/landlord response' 
    //     || this.caseStatus == 'Case closed – resolved without adjudication'
    //     || this.caseStatus== 'Evidence gathering – agent/landlord'
    //     || this.caseStatus=='Evidence gathering - tenant')
    //         return true;
    //     else 
    //         return false;
    // }

    get isShowBackToDepositMangementBtn(){
        if(this.caseParticipantType=='Non-Member Landlord' || this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord'){
            return true;
        }else{
            return false;
        }
    }
    /* EID 92 funds not received showing msg and button code start (Showing for Lead Tenant when Agreed by Agll in repayment)*/
    get isShowrepaymentFundingMSGAgreedByAGLLRepayment(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Repayment'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowFundNotReceivedButtonAgreedByAGLLRepayment(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Repayment'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowTTfundsNotReceivedTrueMSGAgreedByAGLLRepayment(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Repayment'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    /* EID 92 funds not received showing msg and button code end */

    /* EID 95 funds not received showing msg and button code start (Showing for Lead Tenant when Agreed by TT in repayment)*/
    get text_TT_ResWOAdjAmountToTT_0_AgreedByTTRepayment(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
       // && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && (this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant without AmountToTT in Repayment' ||
        this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant without AmountToTT in Selfres' ||
        this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Resolved by RE without AmountToTT in selfres'))
            return true;
        else 
            return false;
    }
    get isShowrepaymentFundingMSGAgreedByTTRepayment(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant with AmountToTT in Repayment'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowFundNotReceivedButtonAgreedByTTRepayment(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && (this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant with AmountToTT in Repayment' || 
        this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Self-Resolution'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant in Self-Resolution'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by AGLL'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by Tenant')
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowTTfundsNotReceivedTrueMSGAgreedByTTRepayment(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && (this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant with AmountToTT in Repayment' ||
        this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Self-Resolution'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant in Self-Resolution' 
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by AGLL'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by Tenant')
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    /* EID 95 funds not received showing msg and button code end */

    // grey text shown to all Tenants when status is 'Case closed – resolved without adjudication'
    get text_Tenant_ResWithoutAdj(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' && this.caseParticipantType=='Tenant'
        && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false
        && (this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Repayment'
         || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Self-Resolution'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant with AmountToTT in Repayment'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant in Self-Resolution'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by AGLL'
        || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by Tenant'))
            return true;
        else 
            return false;
    }

    get text_Case_SelfResolution(){
        if(this.caseStatus == 'Self-resolution')
            return true;
        else 
            return false;
    }

    get text_Case_SelfResolutionAwaitingReview(){
        if(this.caseStatus == 'Self-resolution - awaiting review')
            return true;
        else 
            return false;
    }

    get isShowrepaymentFundingMSGAgreedByAGLLInSelfres(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by AGLL in Self-Resolution'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }

    get isShowrepaymentFundingMSGAgreedByTenantInSelfres(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Agreed by Tenant in Self-Resolution'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }

    get isShowrepaymentFundingMSGofferAcceptedByAGLLInSelfres(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by AGLL'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }

    get isShowrepaymentFundingMSGofferAcceptedByTenantInSelfres(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Offer Accepted by Tenant'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    
    	
    /* EID 25 funds not received showing msg and button code start (Showing for tenants when cancel the dispute in evidence Gathering by AGLL)*/
    get isShowrepaymentFundingMSGCancelledDisputeByAGLL(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Dispute_resolution_status__c == 'Resolved without adjudication'
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == "Agreed by AGLL in Evidence Gathering"
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowFundNotReceivedButtonCancelledDisputeByAGLL(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Dispute_resolution_status__c == 'Resolved without adjudication'
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == "Agreed by AGLL in Evidence Gathering"
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowTTfundsNotReceivedTrueMSGCancelledDisputeByAGLL(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Dispute_resolution_status__c == 'Resolved without adjudication'
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == "Agreed by AGLL in Evidence Gathering"
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }

    // grey side bar
    get text_TT_resolvedWitoutAdjd_EviGtheringAGLL(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' 
        && this.caseParticipant.Case__r.Dispute_resolution_status__c == 'Resolved without adjudication'
        && (this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == "Agreed by AGLL in Evidence Gathering"
         || this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Resolved by RE with AmountToTT in selfres')
        && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    /* EWI 25 funds not received showing msg and button code end */

    /* EID 14 funds not received resolved by RE showing msg and button code start */
    get isShowrepaymentFundingMSGResolvedByRESelfres(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Resolved by RE with AmountToTT in selfres'
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c == false && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowFundNotReceivedButtonResolvedByRESelfres(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && (this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Resolved by RE with AmountToTT in selfres')
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    get isShowTTfundsNotReceivedTrueMSGResolvedByRESelfres(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' && this.isCaseLead == true
        && (this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Resolved by RE with AmountToTT in selfres')
        && this.caseParticipant.Case__r.Deposit_funds_not_received__c && this.caseParticipant.Case__r.Tenant_not_received_funds__c
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }

    // grey side bar
    get text_TT_resolvedWitoutAdjd_resolvedbyRE(){
        if(this.caseStatus == 'Case closed – resolved without adjudication' 
        && this.caseParticipantType=='Tenant' 
        && this.caseParticipant.Case__r.Resolved_Without_Adjudication_Reason__c == 'Resolved by RE with AmountToTT in selfres'
        && this.caseParticipant.Case__r.Tenant_not_received_funds__c == false
        && this.caseParticipant.Case__r.Hide_Grey_Side_Bar__c == false)
            return true;
        else 
            return false;
    }
    /* EID 14 funds not received resolved by RE showing msg and button code end */

    capitalizeWord(element){
        let str = '';
                    let flag = false;
                    if(element!=null && element !='' && element!=undefined){
                    for(let e=0; e<element.length; e++){
                        
                        if (element[e].match(/[a-z]/i)) {
                            if(flag == false){
                             str+=element[e].toUpperCase();
                             flag = true;
                            }else{
                                str+=element[e].toLowerCase();
                            }
                        }else{
                            str+=element[e];
                        }
                    }
                }
                    return str;
    }

    // noBack() { window.history.forward(); }
    
    preventBack() { 
        console.log('preventBack');
        window.history.forward(); 
    }

    connectedCallback(){
    // @wire(CurrentPageReference)
    // getpageRef(pageRef) {
        //window.history.forward();
        //this.noBack();
    // setTimeout(() => { this.preventBack() }, 0); 
    this.preventBack();
        const queryString = window.location.search;
        console.log('queryString => ' + queryString);
        const urlParams = new URLSearchParams(queryString);
        console.log('urlParams => ' + urlParams);
        const accessCode = urlParams.get('accessCode');
        console.log('accessCode => ' + accessCode);
        const reviewProposal = urlParams.get('reviewProposal');
        console.log('reviewProposal => ' + reviewProposal + reviewProposal == 'true');

        if(accessCode){
            this.accessCode = accessCode;
        getPaymentMethod({accessCode : accessCode}).then(result=>{
            console.log('result getPaymentMethod: '+JSON.stringify(result));
            this.paymentMethod = result;
        }).catch(error=>{
            console.log('error in getPaymentMethod : '+JSON.stringify(error));
        });

        setDisputedAmount({accessCode : accessCode}).then(result=>{
            if(result==null){
                return;
            }
            console.log('result setDisputedAmount: '+JSON.stringify(result));
            this.disputedFundsReceived = result[0].disputedFundsReceived;
            this.caseParticipantType = result[0].caseParticipantType;
            this.isPrimaryAgent = result[0].isPrimaryAgent;
        }).catch(error=>{
            console.log('error in setDisputedAmount : '+JSON.stringify(error));
        });

            getCaseParticipantDetails({accessCode : accessCode}).then(result =>{
                console.log("success result : ", result);
                let caseResult = result.caseParticipants;
                this.containsleadtenant = result.containsleadtenant;
                if(caseResult==null){
                    return;
                }
                this.caseParticipant = JSON.parse(JSON.stringify(result.caseParticipants));
                if(result.leadTenant != null && result.leadTenant.Account__r.Name != null){
                    this.leadTenant = (result.leadTenant.Account__r.Name).toLowerCase();
                }
                //this.caseParticipant.Case__r.Lead_Tenant_Name__c = this.caseParticipant.Case__r.Lead_Tenant_Name__c!=null?(this.caseParticipant.Case__r.Lead_Tenant_Name__c).toLowerCase(): '';
                console.log(' this.caseParticipant=='+ JSON.stringify(this.caseParticipant));
            
               

                 // code new start for capitalize each word
                 var postalcode=caseResult.Case__r.Deposit_Account_Number__r.Property__r.Postal_Code__c!=null?caseResult.Case__r.Deposit_Account_Number__r.Property__r.Postal_Code__c.toUpperCase():'';
        
                 var House_No__c = caseResult.Case__r.Deposit_Account_Number__r.Property__r.House_No__c;
                 var Street__c =  caseResult.Case__r.Deposit_Account_Number__r.Property__r.Street__c;
                 var City__c = caseResult.Case__r.Deposit_Account_Number__r.Property__r.City__c ;
                 var County__c = caseResult.Case__r.Deposit_Account_Number__r.Property__r.County__c;
                 var Country__c =  caseResult.Case__r.Deposit_Account_Number__r.Property__r.Country__c;
                 var Saon =  caseResult.Case__r.Deposit_Account_Number__r.Property__r.Saon__c;
                 var claimexceedamounts   =  caseResult.Case__r.Claim_exceed_amount__c;
                 this.claimexceedamount = claimexceedamounts;
                 // code Added by Vidhi Agrawal
                var propadd = '';
                propadd += House_No__c!=null && House_No__c!='' && House_No__c!=undefined 
                ? this.capitalizeWord(House_No__c ) : '';
                propadd += Saon!=null && Saon!='' && Saon!=undefined 
                ? ', '+this.capitalizeWord(Saon ) : '';  
                propadd += Street__c!=null && Street__c!='' && Street__c!=undefined 
                ? ', '+this.capitalizeWord(Street__c ) : '';
                propadd += City__c!=null && City__c!='' && City__c!=undefined 
                ? ', '+this.capitalizeWord(City__c ) : '';
                propadd += County__c!=null && County__c!='' && County__c!=undefined 
                ? ', '+this.capitalizeWord(County__c ) : '';
                propadd += postalcode!=null && postalcode!='' && postalcode!=undefined 
                ? ', '+(postalcode ) : '';
                
                if(propadd[0] == ','){
                    propadd = propadd.replace(',','').trim();
                }
                
                 //  var  propadd=this.capitalizeWord(House_No__c )+', '
                //               +this.capitalizeWord(Saon )+', '
                //               +this.capitalizeWord(Street__c )+', '
                //               +this.capitalizeWord(City__c )+', '
                //               +this.capitalizeWord(County__c )+', '
                //               +postalcode            
                 
                 //code new endfor capitalize each word
              
                // var propaddress = caseResult.Case__r.Deposit_Account_Number__r.Property_Address__c;
                // propadd = propadd.replace(", , , ,", ",");
                // propadd = propadd.replace(", , , ", ",");
                // propadd = propadd.replace(", ,", ",");
                //propadd = propadd.replace(',','');
                
                // code Added by Vidhi Agrawal END

                this.propertyaddress = propadd;
                
                this.AGLL_Raised_Respond = caseResult.AGLL_Raised_Respond__c;
                var endDate =new Date( caseResult.Case__r.Deposit_Account_Number__r.End_Date__c);
                var respondDate = new Date(caseResult.Case__r.Respond_Date__c);
                console.log('responddate='+respondDate);
                if(isNaN(endDate)){
                    this.depositEndDate='';
                } 
                else if(endDate!= null || endDate!= undefined|| endDate!= ''){
                    var checkdate = endDate.getDate().toString().padStart(2, "0");;
                    var checkmonth = (endDate.getMonth()+1).toString().padStart(2, "0");
                    var checkyear = endDate.getFullYear();
                    var newDate = checkdate +'/'+ checkmonth+'/'+checkyear;
                    console.log('this.newDate==='+ endDate );
                    this.depositEndDate = newDate;
                    console.log('depositEndDate==='+this.depositEndDate);     
                }  
                
                if(isNaN(respondDate)){
                    this.caseRespondDate='';
                } 
                else if(respondDate!= null || respondDate!= undefined|| respondDate!= ''){
                    var checkdate1 = respondDate.getDate().toString().padStart(2, "0");;
                    var checkmonth1 = (respondDate.getMonth()+1).toString().padStart(2, "0");
                    var checkyear1 = respondDate.getFullYear();
                    var newDate1 = checkdate1 +'/'+ checkmonth1+'/'+checkyear1;
                    console.log('this.newDate==='+ respondDate );
                    this.caseRespondDate = newDate1;
                    console.log('respondDate==='+this.caseRespondDate);
                }  
                    
                console.log('depositEndDateElse==='+this.depositEndDate);
                this.caseStatus = caseResult.Case__r.Status;
                if(caseResult.Case__r.Status =='Proposal submitted- tenant'){
                    this.status = 'Proposal submitted – tenant';
                }
                else{
                    this.status = caseResult.Case__r.Status;
                }
                this.isCaseLead = caseResult.Is_Lead__c;
                this.caseParticipantType = caseResult.Type__c;
                this.depositAmount = caseResult.Case__r.Deposit_Account_Number__r.Deposit_Amount__c >= 0 ? Number(caseResult.Case__r.Deposit_Account_Number__r.Deposit_Amount__c).toFixed(2) : 0.00;
                this.initialAmountToTenant = caseResult.Case__r.Amount_Returned_to_Landlord__c >= 0 ? Number(caseResult.Case__r.Amount_Returned_to_Landlord__c).toFixed(2) : 0.00;
                this.initialAmountToAGLL = Number(this.depositAmount - this.initialAmountToTenant).toFixed(2);
                if(reviewProposal == 'true'){
                    this.isShowReviewProposalSummary = true;
                }else {
                    this.isShowDepositSummary = true;
                }
    
                // if(this.caseStatus=='New' isReviewProposalTT& this.caseParticipantType=='Tenant'){ // not in use because it is not in most recent doc of EID 94
                //     this.text_Tenant_New = true;
                // }
                // else 
                if(this.caseStatus=='New' && (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord' || this.caseParticipantType=='Non-Member Landlord')){
                    this.text_Agll_New = true;
                }
                else if(this.caseStatus=='Proposal submitted- tenant' && this.isCaseLead== true && this.caseParticipantType=='Tenant' ){
                    this.text_LeadTenant_Proposalsubmittedtenant = true;
                }
                else if(this.caseStatus=='Proposal submitted- tenant' && this.isCaseLead== false && this.caseParticipantType=='Tenant' ){
                    this.text_JointTenant_Proposalsubmittedtenant = true;
                }
                // else if(this.caseStatus=='Proposal submitted – agent/landlord' && (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord') ){
                //     this.text_Agll_ProposalsubmittedAGLL = true;
                // }
                else if(this.caseStatus=='Proposal submitted – agent/landlord' && this.AGLL_Raised_Respond == true &&
                (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord' || this.caseParticipantType=='Non-Member Landlord') ){
                    this.text_AgllNonMember_ProposalsubmittedAGLL = true;
                }
                else if(this.caseStatus=='Proposal submitted – agent/landlord' && this.caseParticipantType=='Non-Member Landlord' ){
                    this.text_NonMember_ProposalsubmittedAGll = true;
                }
                else if(this.caseStatus=='Proposal submitted – agent/landlord' && this.AGLL_Raised_Respond == false && this.caseParticipantType=='Agent' ){
                    this.text_AGLL_ProposalsubmittedNonMember = true; // need to add gray side bar
                }
                else if(this.caseStatus=='Proposal submitted – awaiting tenant response' && this.caseParticipantType=='Tenant' ){
                    this.text_Tenant_AwaitingTenantResponse = true;
                }
                else if(this.caseStatus=='Proposal submitted – awaiting agent/landlord response' && (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord' || this.caseParticipantType=='Non-Member Landlord')){
                    this.text_AgLL_AwaitingAGLLResponse = true;
                }
                else if(this.caseStatus=='Evidence gathering agent/landlord' && this.isCaseLead== true && this.caseParticipantType=='Tenant' ){
                    this.text_LeadTenant_EvidencegatheringAGLL = true;
                }
                else if(this.caseStatus=='Evidence gathering agent/landlord' && this.isCaseLead== false && this.caseParticipantType=='Tenant' ){
                    this.text_JointTenant_EvidencegatheringAGLL = true;
                }
                else if(this.caseStatus=='Evidence gathering tenant' && this.isCaseLead== true && this.caseParticipantType=='Tenant' ){
                    this.text_LeadTenant_EvidencegatheringTenant = true;
                }
                else if(this.caseStatus=='Evidence gathering tenant' && (this.isCaseLead== false && this.containsleadtenant==true) && this.caseParticipantType=='Tenant' ){
                    this.text_JointTenant_EvidencegatheringTenant = true;
                }
                else if(this.caseStatus=='Evidence gathering tenant' && (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord' || this.caseParticipantType=='Non-Member Landlord')){
                    this.text_AGLL_EvidencegatheringTenant = true;
                }
                else if(this.caseStatus=='Evidence gathering agent/landlord' && (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord' || this.caseParticipantType=='Non-Member Landlord')){
                    this.text_AGLL_SubmitEvidence = true;
                }
                else if(this.caseStatus=='Self-resolution' && (this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord' ||  this.caseParticipantType=='Non-Member Landlord')){
                    this.text_Case_SelfResolutionAGLL = true;
                }
                else if(this.caseStatus=='Self-resolution' &&  this.caseParticipantType=='Tenant'){
                    this.text_Case_SelfResolutionTT = true;
                }

                this.disputeItemsStatic.push({value:0, key:'Cleaning'});
                this.disputeItemsStatic.push({value:0, key:'Damage'});
                this.disputeItemsStatic.push({value:0, key:'Redecoration'});
                this.disputeItemsStatic.push({value:0, key:'Gardening'});
                this.disputeItemsStatic.push({value:0, key:'Rent'});
                this.disputeItemsStatic.push({value:0, key:'Other'});

                getCaseandDispiteItemsDetails({caseId : caseResult.Case__c}).then(result=>{
                    console.log('getCaseandDispiteItemsDetails result=> ' + JSON.stringify(result));
                    if(result.Case_Participants__r[0].Account__r.Name !=undefined && result.Case_Participants__r.length>0){
                        this.agllName = result.Case_Participants__r[0].Account__r.Name ? result.Case_Participants__r[0].Account__r.Name : '';
                    }
                    let calimItems = [];
                    let getdisputeItems = JSON.parse(JSON.stringify(result.Dispute_Items__r));
                    for(let i in this.disputeItemsStatic){
                        console.log('this.disputeItemsStatic[i].key => ' + this.disputeItemsStatic[i].key);
                        for(let j in getdisputeItems){
                            console.log('getdisputeItems[j].Type__c => ' + getdisputeItems[j].Type__c);
                            if(this.disputeItemsStatic[i].key == getdisputeItems[j].Type__c){
                                if(getdisputeItems[j].Type__c.includes('Rent'))
                                    getdisputeItems[j].Type__c = 'Rent arrears';
                                calimItems.push(getdisputeItems[j]);
                            }
                        }
                    }
                    console.log("**calimItems => " + calimItems);
                    this.disputeItems = calimItems;
    
                    // this.disputeItems = JSON.parse(JSON.stringify(result.Dispute_Items__r));
                    for(let ind = 0; ind<this.disputeItems.length; ind++ ){
                        // console.log('disputeItems['+ind+'].Type__c => ' + this.disputeItems[ind].Type__c);
                        if( this.disputeItems[ind].Claimed_by_Landlord__c > 0){
                            this.disputeItems[ind].Claimed_by_Landlord__c = (parseFloat(this.disputeItems[ind].Claimed_by_Landlord__c)).toFixed(2);
                            if(this.disputeItems[ind].Type__c == 'Other'){
                                this.otherDisputeReason = this.disputeItems[ind].Other_Reason__c;
                                console.log("otherDisputeReason => "+ this.otherDisputeReason);
                            }
                        }else{
                            this.disputeItems.splice(ind, 1);
                            ind--;
                        }
                    }
                    console.log('this.disputeItems => ' + JSON.stringify(this.disputeItems));
        
                }).catch(error=>{
                    console.log('getCaseandDispiteItemsDetails error=> ' + error);
                    console.log('getCaseandDispiteItemsDetails error=> ' + JSON.stringify(error));
                }); 

            }).catch(error => {
                console.log('error : ', error)
            });
        }
        
    }
    
    handleContinueAGLL(event) {
        if(this.caseParticipantType=='Non-Member Landlord' || this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord'){
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'ewiaglldepositallocationproposal' //'ewirepaymentrequestedbyagll'
                },
                state:{
                    accessCode : this.caseParticipant.Access_Code__c
                }   
            });
        }
    }

    handleSelfResultionContinue(event) {
        // if(this.caseParticipantType=='Non-Member Landlord' || this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord'){
        //     this[NavigationMixin.Navigate]({
        //         type: 'comm__namedPage',
        //         attributes: {
        //             pageName: 'ewiagllselfresolution'
        //         },
        //         state:{
        //             accessCode : this.caseParticipant.Access_Code__c
        //         }   
        //     });
        // }
        // else if(this.caseParticipantType == 'Tenant' && this.isCaseLead == true){
        //     this[NavigationMixin.Navigate]({
        //         type: 'comm__namedPage',
        //         attributes: {
        //             pageName: 'ewitenantselfresolution'
        //         },
        //         state:{
        //             accessCode : this.caseParticipant.Access_Code__c
        //         }   
        //     });
        // }
        // commented by himanshu 15/02/2023
        console.log('inside handleSubmitEvidenceAGLL');
        getCaseCurrentDetails({accessCode : this.accessCode}).then(result => {
            console.log('result => ' + result);
            if(result.Case__r.Status == 'Self-resolution' ){
            if(this.caseParticipantType=='Non-Member Landlord' || this.caseParticipantType=='Agent' || this.caseParticipantType=='Independent-Landlord'){
                this[NavigationMixin.Navigate]({
                    type: 'comm__namedPage',
                    attributes: {
                        pageName: 'ewiagllselfresolution'
                    },
                    state:{
                        accessCode : this.caseParticipant.Access_Code__c
                    }   
                });
            }
            else if(this.caseParticipantType == 'Tenant' && this.isCaseLead == true){
                this[NavigationMixin.Navigate]({
                    type: 'comm__namedPage',
                    attributes: {
                        pageName: 'ewitenantselfresolution'
                    },
                    state:{
                        accessCode : this.caseParticipant.Access_Code__c
                    }   
                });
            }
            }else{
                window.location.reload();
            }
        }).catch(error => {
            console.log("getCaseCurrentDetails error => ", error);
        });
        // else if(this.caseParticipantType == 'Tenant' && this.isCaseLead == false ){
        //     this[NavigationMixin.Navigate]({
        //         type: 'comm__namedPage',
        //         attributes: {
        //             pageName: 'ewitenantselfresolutionviewonly'
        //         },
        //         state:{
        //             accessCode : this.caseParticipant.Access_Code__c
        //         }   
        //     });
        // }

    }

    handleSelfResultionViewOnlyContinue(event) {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'ewiagllselfresolutionviewonly'
                },
                state:{
                    accessCode : this.caseParticipant.Access_Code__c
                }   
            });

    }

    handleSelfResultionContinueviewonlytott(event) {
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'ewitenantselfresolutionviewonly'
            },
            state:{
                accessCode : this.caseParticipant.Access_Code__c
            }   
        });

}

    handleReviewProposalAGLL(event){
        if(this.caseStatus=='Proposal submitted – awaiting agent/landlord response')
        {
            this[NavigationMixin.Navigate]({
                type: 'comm__namedPage',
                attributes: {
                    pageName: 'ewirepaymentrespondbyagll'
                },
                state:{
                    accessCode : this.caseParticipant.Access_Code__c
                }   
            });
        }else if(this.caseStatus == 'Proposal submitted – agent/landlord' || this.caseStatus=='Proposal submitted – awaiting tenant response'){
            this.isShowDepositSummary = false;
            this.isShowReviewProposalSummary = true;
            // getCaseandDispiteItemsDetails({caseId : this.caseParticipant.Case__c}).then(result=>{
            //     console.log('getCaseandDispiteItemsDetails result=> ' + JSON.stringify(result));
            //     this.agllName = result.Case_Participants__r[0].Account__r.Name ? result.Case_Participants__r[0].Account__r.Name : '';
            //     let calimItems = [];
            //     let getdisputeItems = JSON.parse(JSON.stringify(result.Dispute_Items__r));
            //     for(let i in this.disputeItemsStatic){
            //         console.log('this.disputeItemsStatic[i].key => ' + this.disputeItemsStatic[i].key);
            //         for(let j in getdisputeItems){
            //             console.log('getdisputeItems[j].Type__c => ' + getdisputeItems[j].Type__c);
            //             if(this.disputeItemsStatic[i].key == getdisputeItems[j].Type__c){
            //                 if(getdisputeItems[j].Type__c.includes('Rent'))
            //                     getdisputeItems[j].Type__c = 'Rent arrears';
            //                 calimItems.push(getdisputeItems[j]);
            //             }
            //         }
            //     }
            //     console.log("**calimItems => " + calimItems);
            //     this.disputeItems = calimItems;

            //     // this.disputeItems = JSON.parse(JSON.stringify(result.Dispute_Items__r));
            //     for(let ind = 0; ind<this.disputeItems.length; ind++ ){
            //         // console.log('disputeItems['+ind+'].Type__c => ' + this.disputeItems[ind].Type__c);
            //         if( this.disputeItems[ind].Claimed_by_Landlord__c > 0){
            //             this.disputeItems[ind].Claimed_by_Landlord__c = (parseFloat(this.disputeItems[ind].Claimed_by_Landlord__c)).toFixed(2);
            //             if(this.disputeItems[ind].Type__c == 'Other'){
            //                 this.otherDisputeReason = this.disputeItems[ind].Other_Reason__c;
            //                 console.log("otherDisputeReason => "+ this.otherDisputeReason);
            //             }
            //         }else{
            //             this.disputeItems.splice(ind, 1);
            //             ind--;
            //         }
            //     }
            //     console.log('this.disputeItems => ' + JSON.stringify(this.disputeItems));
            //     this.isShowDepositSummary = false;
            //     this.isShowReviewProposalSummary = true;
            // }).catch(error=>{
            //     console.log('getCaseandDispiteItemsDetails error=> ' + (error));
            //     console.log('getCaseandDispiteItemsDetails error=> ' + JSON.stringify(error));
            // }); 
        }
    }

    handleReviewProposalTT(){
        this.isShowDepositSummary = false;
        this.isShowReviewProposalSummary = true;
        // getCaseandDispiteItemsDetails({caseId : this.caseParticipant.Case__c}).then(result=>{
        //     console.log('getCaseandDispiteItemsDetails result=> ' + JSON.stringify(result));
        //     this.agllName = result.Case_Participants__r[0].Account__r.Name ? result.Case_Participants__r[0].Account__r.Name : '';
        //     let calimItems = [];
        //     let getdisputeItems = JSON.parse(JSON.stringify(result.Dispute_Items__r));
        //     for(let i in this.disputeItemsStatic){
        //         console.log('this.disputeItemsStatic[i].key => ' + this.disputeItemsStatic[i].key);
        //         for(let j in getdisputeItems){
        //             console.log('getdisputeItems[j].Type__c => ' + getdisputeItems[j].Type__c);
        //             if(this.disputeItemsStatic[i].key == getdisputeItems[j].Type__c){
        //                 if(getdisputeItems[j].Type__c.includes('Rent'))
        //                     getdisputeItems[j].Type__c = 'Rent arrears';
        //                 calimItems.push(getdisputeItems[j]);
        //             }
        //         }
        //     }
        //     console.log("**calimItems => " + calimItems);
        //     this.disputeItems = calimItems;

        //     // this.disputeItems = JSON.parse(JSON.stringify(result.Dispute_Items__r));
        //     for(let ind = 0; ind<this.disputeItems.length; ind++ ){
        //         // console.log('disputeItems['+ind+'].Claimed_by_Landlord__c => ' + this.disputeItems[ind].Claimed_by_Landlord__c.toFixed(2));
        //         if( this.disputeItems[ind].Claimed_by_Landlord__c > 0){
        //             this.disputeItems[ind].Claimed_by_Landlord__c = (parseFloat(this.disputeItems[ind].Claimed_by_Landlord__c)).toFixed(2);
        //             if(this.disputeItems[ind].Type__c == 'Other'){
        //                 this.otherDisputeReason = this.disputeItems[ind].Other_Reason__c;
        //                 console.log("otherDisputeReason => "+ this.otherDisputeReason);
        //             }
        //         }else{
        //             this.disputeItems.splice(ind, 1);
        //             ind--;
        //         }
        //     }
        //     console.log('this.disputeItems => ' + JSON.stringify(this.disputeItems));
        //     this.isShowDepositSummary = false;
        //     this.isShowReviewProposalSummary = true;
            

        // }).catch(error=>{
        //     console.log('getCaseandDispiteItemsDetails error=> ' + (error));
        //     console.log('getCaseandDispiteItemsDetails error=> ' + JSON.stringify(error));
        // });  
    }

    handleFundsNotReceived(){
        updateTenantfundstatus({caseId: this.caseParticipant.Case__c})
        .then(result => {
            console.log("updateTenantfundstatus result => " + result);
            this.caseParticipant.Case__r.Tenant_not_received_funds__c = true;
        }).catch(error => {
            console.log("updateTenantfundstatus error => ", error);
        });
    }

    handleGotoDepositSummary(event){
        event.preventDefault();
        this.isShowDepositSummary = true;
        this.isShowReviewProposalSummary = false;
    }

    
    handleSubmitEvidenceAGLL(event){
        console.log('inside handleSubmitEvidenceAGLL');
        getCaseCurrentDetails({accessCode : this.accessCode}).then(result => {
            console.log('result => ' + result);
            if(result.Case__r.Status == 'Evidence gathering agent/landlord' && (result.Type__c =='Non-Member Landlord' ||
                result.Type__c =='Agent' || result.Type__c =='Independent-Landlord')
                && result.AGLL_Raised_Respond__c == true)
            {
                this[NavigationMixin.Navigate]({
                    type: 'comm__namedPage',
                    attributes: {
                        pageName: 'ewievidencegatheringagll'
                    },
                    state:{
                        accessCode : this.caseParticipant.Access_Code__c
                    }   
                });
            }else{
                window.location.reload();
            }
        }).catch(error => {
            console.log("getCaseCurrentDetails error => ", error);
        });
    }

    handleShowDisputedAmount(event){
        console.log('inside handleShowDisputedAmount');
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'ewishowdisputedamountagll'
            },
            state:{
                accessCode : this.caseParticipant.Access_Code__c
            }   
        });
    }

    handleChangePayment(event){
        console.log('inside handleChangePayment');
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'ewishowdisputedamountagll'
            },
            state:{
                accessCode : this.caseParticipant.Access_Code__c,
                paymentMethod : this.paymentMethod
            }   
        });
    }

    handleSubmitEvidenceLeadTT(event){
        console.log('inside handleSubmitEvidenceLeadTT');
        getCaseCurrentDetails({accessCode : this.accessCode}).then(result => {
            console.log('result => ' + result);
            if(result.Case__r.Status == 'Evidence gathering tenant'
                && result.Type__c =='Tenant' && ((result.Is_Lead__c == true && this.containsleadtenant ==true) ||(result.Is_Lead__c == false && this.containsleadtenant ==false)) )
            {
                this[NavigationMixin.Navigate]({
                    type: 'comm__namedPage',
                    attributes: {
                        pageName: 'ewievidencegatheringtt'
                    },
                    state:{
                        accessCode : this.caseParticipant.Access_Code__c
                    }   
                });
            }else{
                window.location.reload();
            }
        }).catch(error => {
            console.log("getCaseCurrentDetails error => ", error);
        });
    }

    handleReviewEvidenceofAGLL(event){
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'ewireviewevidence' // 'reviewewievidencegatheringagll'
            },
            state:{
                accessCode : this.caseParticipant.Access_Code__c
            }   
        });
    }

    handleReviewEvidenceofTTandAGLL(event){
        this[NavigationMixin.Navigate]({
            type: 'comm__namedPage',
            attributes: {
                pageName: 'ewireviewevidence' // 'reviewewievidencegatheringtt'
            },
            state:{
                accessCode : this.caseParticipant.Access_Code__c
            }   
        });
    }
}