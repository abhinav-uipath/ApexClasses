import { LightningElement, api, track } from 'lwc';
import NI_THEME from '@salesforce/resourceUrl/NI_Theme';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import RecaptchaHandler from '@salesforce/apex/EI_NI_RecaptchaDemo.insertRecord';
import createCallMeBack from '@salesforce/apex/EI_NI_CallBackController.createCallMeBack';
import sendEmail from '@salesforce/apex/EI_NI_CallBackController.sendConfirmationEmail';
import getPhoneCodePiclistValues from '@salesforce/apex/EI_NI_CallBackController.getPhoneCodePiclistValues';

export default class Ei_NI_Website_CallMeBackButton extends LightningElement {
    cancel_icon = NI_THEME + '/assets/img/Cancel-icon.png';
    @track showSubmit = false;
    @track showModal = false;
    @track phoneCodelist = [];
    @track postalCodesList = [];
    showThankYou = false;

    showSchemeError = false;
    isSchemeSelected = true;
    isInterestSelected = true;
    showInterestError = false;
    mobileLengthOrPatternError = false;
    mobileNumber = '';
    landlineNumber = ''
    isValid = false;
    isPhoneLandlineError = false
    @track phoneCode = '';
    @api ToEmail;
   

    @track callbackRecord = {
        "sObjectType": "Call_Me_Back__c"
    };

    objectId = '';

    connectedCallback() {
        /* Promise.all([
            loadStyle(this, `${NI_THEME}/assets/css/custom-ni.css`),
            loadScript(this, NI_THEME + '/assets/js/plugin.min.js'),
            loadScript(this, NI_THEME + '/assets/js/custom.js'),
            loadScript(this, NI_THEME + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_THEME + '/assets/js/datepicker.js')

        ]).then(() => {
            console.log('Files loaded');
        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        }); */
        getPhoneCodePiclistValues()
            .then(result => {
                if (result) {
                    //this.result = result;
                    this.phoneCodePicklist = result;
                    for (var eachCode in result) {
                        if (eachCode === '+44') {
                            this.phoneCode = '+44';
                            console.log('line 53'+this.phoneCodelist);
                            this.phoneCodelist.push({ key: result[eachCode], value: true });
                        } else {
                            this.phoneCode = '+44';
                            this.phoneCodelist.push({ key: result[eachCode], value: false });
                            
                            console.log('line 58'+this.phoneCodelist);
                        }
                        
                    }
                }
                console.log('Success');
                console.log('line 57'+this.phoneCode);
                console.log('line 63'+this.phoneCodePicklist);

            })
            .catch(error => {
                console.log('Error -> ', error);
            })

    }

    get interests() {
        return [
            { label: 'Please select an option', value: '' },
            { label: 'Custodial', value: 'Custodial' },
            { label: 'Insured', value: 'Insured' },
            { label: 'Other', value: 'Other' }
        ]
    }

    get depositSchemes() {
        return [
            { label: 'Please select your current deposit scheme', value: '' },
            { label: 'DPS', value: 'DPS' },
            { label: 'My Deposit', value: 'My Deposit' },
            { label: 'Other', value: 'Other' }
        ]
    }

    openForm() {
        this.showThankYou = false;
        this.showModal = true;
    }

    closeModal() {
        this.showModal = false;
    }

    handleCaptcha(event) {
        console.log('received message from child');
        console.log('childMessage', JSON.stringify(event.detail));
        if (!event.detail.value && (event.detail.response != null && event.detail.response != "" && event.detail.response != undefined)) {
            RecaptchaHandler({
                recaptchaResponse: event.detail.response
            }).then(result => {
                if (result.includes('Success')) {
                    this.showSubmit = true;
                } else {
                    this.showSubmit = false;
                }
                console.log('Result:::', result);
            }).catch(error => {
                this.showSubmit = false;
                console.log('Error while validating Captcha::', JSON.stringify(error));
            })
        } else if (event.detail.value) {
            this.showSubmit = false;
        }
    }

    isInputValid() {
        let isValid = true;
        let inputFields = this.template.querySelectorAll(".validate");
        inputFields.forEach(inputField => {
            if (!inputField.checkValidity()) {
                inputField.reportValidity();
                isValid = false;
            }
            this.callbackRecord[inputField.name] = inputField.value;
        });
        return isValid;
    }

    handleDepositScheme(event) {
        if(event.target.value == '') {
            this.showSchemeError = true;
        } else {
            this.callbackRecord['Current_Deposit_Scheme__c'] = event.target.value;
            this.showSchemeError = false;
            this.isSchemeSelected = false;
        }
    }

    handleInterest(event) {
        if(event.target.value == '') {
            this.showInterestError = true;
        } else {
            this.callbackRecord['Interested_In__c'] = event.target.value;
            this.showInterestError = false;
            this.isInterestSelected = false;
        }
    }
    handledPhonecode(event){
        this.phoneCode = event.target.value;
        console.log('line 150'+this.phoneCode);
        if(this.mobileNumber.length == 0){
            this.mobileLengthOrPatternError = false;
            this.mobileValidate = false;
        } else if(this.mobileNumber.length != 11 && this.phoneCode == '+44') {
            console.log('line 161'+this.mobileNumber.length);
            
            this.mobileLengthOrPatternError = true;
            this.mobileValidate = true;
            this.isValid = false;
        } else {
            this.callbackRecord['Phone_Code__c'] = this.phoneCode;
            this.mobileLengthOrPatternError = false;
            this.mobileValidate = false;
            this.isValid = true;
        }
    }

    handledPhoneChange(event) {
       // let dataId = event.target.dataset.name;
        //let dataName = event.target.name;
        this.mobileNumber = event.target.value;
        console.log('handledPhoneChange'+this.mobileNumber);
        console.log('line 161'+this.phoneCode);
        if(this.mobileNumber.length == 0){
            this.mobileLengthOrPatternError = false;
            this.mobileValidate = false;
        } else if(this.mobileNumber.length != 11 && this.phoneCode == '+44') {
            console.log('line 161'+this.mobileNumber.length);
            
            this.mobileLengthOrPatternError = true;
            this.mobileValidate = true;
            this.isValid = false;
        } else {
            this.callbackRecord['Phone_Code__c'] = this.phoneCode;
            this.callbackRecord['Your_Phone_Number__c'] = this.mobileNumber;
            this.mobileLengthOrPatternError = false;
            this.mobileValidate = false;
            this.isValid = true;
        }
    }

    handledLandlineChange(event){
        this.landlineNumber = event.target.value; 
        this.callbackRecord['Landline_Number__c'] = this.landlineNumber;
        this.isValid = true;
    }
    // if (landLineNumber == null || landLineNumber == "" || landLineNumber == undefined) {
    //     if (mobileNumber == null || mobileNumber == "" || mobileNumber == undefined) {
    //         this.phoneNumError = true;
    //         isValid = false;
    //     }
    // }
    // if (mobileNumber == null || mobileNumber == "" || mobileNumber == undefined) {
    //     if (landLineNumber == null || landLineNumber == "" || landLineNumber == undefined) {
    //         this.phoneNumError = true;
    //         isValid = false;
    //     }
    // }

    submitForm() {
        //this.isValid = true;
        // if(this.mobileValidate){
        //     this.mobileLengthOrPatternError = true;
        // } else {
        //     this.callbackRecord['Phone_Code__c'] = this.phoneCode;
        // }
        let LandlineNumber = this.template.querySelector('lightning-input[data-id="LandlineNumber"]').value;
        let mobilenumber = this.template.querySelector('lightning-input[data-id="mobileNumber"]').value;
        console.log('line 224'+LandlineNumber);
        console.log('line 225'+mobilenumber);
        
        let comments = this.template.querySelector('lightning-textarea[data-name="comments"]').value;
        if (comments != null && comments != "" && comments != undefined) {
            this.callbackRecord['Additional_comments__c'] = comments;
        }
        
        if(this.isSchemeSelected || this.isInterestSelected) {
            if(mobilenumber.trim() == "" && LandlineNumber.trim() == ""){
                //this.showToast();
                //this.isValid = false; 
                //this.isPhoneLandlineError = true
                alert('Please enter either Landline number or Phone number.');
            } 
            // else {
            //     this.isPhoneLandlineError = false;
            // }
            this.showSchemeError = true;
            this.showInterestError = true;
            this.isInputValid();
        } 
        else if((mobilenumber == null || mobilenumber.trim() == "" || mobilenumber == undefined) && (LandlineNumber == null || LandlineNumber.trim() == "" || LandlineNumber == undefined)){
            
                        // this.phoneNumError = true;
                        //this.showToast();
                        //this.isPhoneLandlineError = true;
                        alert('Please enter either Landline number or Phone number.');
                        this.isValid = false;
                
        }  
        // else {
        //             this.isPhoneLandlineError = false;
        // }

          if (this.isInputValid() && !this.isSchemeSelected && !this.isInterestSelected && this.isValid) {
            console.log('CallBack Data>>>>' + JSON.stringify(this.callbackRecord));
            createCallMeBack({
                "callbackRecord": this.callbackRecord
            }).then(result => {
                console.log('Result is >>>>' + JSON.stringify(result));
                if (result) {
                    this.objectId = result;
                    this.showThankYou = true;
                    sendEmail({
                        "recId" : this.objectId
                    }).then(result => {
                        console.log('Send Email Result>>>' + JSON.stringify(result));
                    }).catch(error => {
                        console.log('Error sending email>>>>' + JSON.stringify(error));
                    })
                }
            }).catch(error => {
                console.log('Error is>>>' + JSON.stringify(error));
            })
        }
    }
    onlyNumberKey(event) {
        if(!(event.key == 0 || event.key == 1 || event.key == 2 || event.key == 3 || event.key == 4 || event.key == 5 || event.key == 6 || event.key == 7 || event.key == 8 || event.key == 9)){
            event.preventDefault();
        }
    }
    
    /*hideBootstrapErrors(event) {
        var button_Name = event.target.name;
        switch (button_Name) {
            case "isPhoneLandlineErrorMsg":
                this.isPhoneLandlineError = false;
                break;
        }
    }*/
    // showToast() {
    //     const event = new ShowToastEvent({
    //         //title: 'Only NI postcodes are allwed',
    //         message: 'Please enter either Landline number or Phone number',
    //         variant: 'warning',
    //         mode: 'dismissable'
    //     });
    //     this.dispatchEvent(event);
    // }
}