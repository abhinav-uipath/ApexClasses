import { LightningElement, track } from 'lwc';
import NI_THEME from '@salesforce/resourceUrl/NI_Theme';
//import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import customStyles from './eI_NI_Website_SendAnEnquiryOnline.css';

import RecaptchaHandler from '@salesforce/apex/EI_NI_RecaptchaDemo.insertRecord';
import getPostalCodes from '@salesforce/apex/EI_NI_Website_SendAnEnquiryOnline.fetchPostCodes';
//import createLead from '@salesforce/apex/EI_NI_Website_SendAnEnquiryOnline.createLead';
import sendEmail from '@salesforce/apex/EI_NI_Website_SendAnEnquiryOnline.sendConfirmationEmail';

export default class EI_NI_Website_SendAnEnquiryOnline extends LightningElement {
    @track showSubmit = false;
    @track showCorresAddress = true;


    back_icon = NI_THEME + '/assets/img/arrow_right_white.png';
    

    @track leadRecord = {
        "sObjectType": "Lead"
    };
    @track address = { AddressLine: '', Street: '', Town: '', County: '', Postcode: '', Country: '', localAuthorityArea: '' };

    postalCodesList = [];
    showThankYou = false;
    isAddressNotNI = false;
    reasonOne = false;
    reasonTwo = false;
    reasonThree = false;
    reasonFour = false;
    reasonFive = false;

    contactReasonError = false;
    isConReasonSelected = true;
    IamAError = false;
    isIAmSelected = true;
    depositTypeError = false;
    isDepoTypeSelected = true;
    isAddressValidError = false;
    isAddressVaild = true;
    isValidAdress = false;
    ContactReason = '';
    FirstName = '';
    LastName = '';
    IamA = '';
    Email = '';
    DAN = '';
    DepositType = '';
    Postalcode = '';
    houseNo = '';
    Street = '';
    Town = '';
    County = '';
    YourMsg = '';



    connectedCallback() {
        getPostalCodes({}).then(result => {
            this.postalCodesList = result;
            console.log('line 43'+this.postalCodesList);
        }).catch(error => {
            console.log('Error fetching postcodes>>>' + JSON.stringify(error));
        })

        const style = document.createElement('style');
        style.innerHTML = customStyles;
        // this.template.querySelector('Contact_Reason__c').appendChild(style);
        /* Promise.all([
            getPostalCodes({}).then(result => {
                this.postalCodesList = result;
            }).catch(error => {
                console.log('Error fetching postcodes>>>' + JSON.stringify(error));
            }),
            loadStyle(this, `${NI_THEME}/assets/css/custom-ni.css`),
            loadScript(this, NI_THEME + '/assets/js/plugin.min.js'),
            loadScript(this, NI_THEME + '/assets/js/custom.js'),
            loadScript(this, NI_THEME + '/assets/js/jquery.dataTables.min.js'),
            loadScript(this, NI_THEME + '/assets/js/datepicker.js')

        ]).then(() => {
            console.log('Files loaded');
        }).catch(error => {
            console.log('Error => ', JSON.stringify(error));
        }); */

    }

    get contactResons() {
        return [
            { label: 'Please select why you are contacting us', value: '' },
            { label: 'Is My Deposit Protected?', value: 'Is My Deposit Protected?' },
            { label: 'I want An Update On A Dispute Already Submitted', value: 'I want An Update On A Dispute Already Submitted' },
            { label: 'I Want to Raise a Dispute', value: 'I Want to Raise a Dispute' },
            { label: "I'm having Trouble Loggin In", value: "I'm having Trouble Loggin In" },
            { label: 'I Would Like to Request A Repayment (Custodial)', value: 'I Would Like to Request A Repayment (Custodial)' },
            { label: 'General', value: 'General' }
        ]
    }

    get depositTypes() {
        return [
            { label: 'Please select a deposit type', value: '' },
            { label: 'Insured (Landlord Or Agent Holds The Deposit)', value: 'Insured (Landlord Or Agent Holds The Deposit)' },
            { label: 'Custodial (TDS Holds The Deposit)', value: 'Custodial (TDS Holds The Deposit)' },
            { label: 'Not Sure', value: 'Not Sure' }
        ]
    }

    get whatAreYou() {
        return [
            { label: 'Please select type', value: '' },
            { label: 'Tenant', value: 'Tenant' },
            { label: 'Landlord', value: 'Landlord' },
            { label: 'Agent', value: 'Agent' },
            { label: 'Other', value: 'Other' }
        ]
    }

    handleContactReasons(event) {
        var selectedReason = event.target.value;
        if (selectedReason == '') {
            this.contactReasonError = true;
            this.reasonOne = false;
            this.reasonTwo = false;
            this.reasonThree = false;
            this.reasonFour = false;
            this.reasonFive = false;
        } else {
            console.log('Inside else>>>'+selectedReason);
            switch (selectedReason) {
                case "Is My Deposit Protected?":
                    this.reasonOne = true;
                    this.reasonTwo = false;
                    this.reasonThree = false;
                    this.reasonFour = false;
                    this.reasonFive = false;
                    break;
                case "I want An Update On A Dispute Already Submitted":
                    this.reasonTwo = true;
                    this.reasonOne = false;
                    this.reasonThree = false;
                    this.reasonFour = false;
                    this.reasonFive = false;
                    break;
                case "I Want to Raise a Dispute":
                    this.reasonThree = true;
                    this.reasonOne = false;
                    this.reasonTwo = false;
                    this.reasonFour = false;
                    this.reasonFive = false;
                    break;
                case "I'm having Trouble Loggin In":
                    this.reasonFour = true;
                    this.reasonOne = false;
                    this.reasonTwo = false;
                    this.reasonThree = false;
                    this.reasonFive = false;
                    break;
                case "I Would Like to Request A Repayment (Custodial)":
                    this.reasonFive = true;
                    this.reasonOne = false;
                    this.reasonTwo = false;
                    this.reasonThree = false;
                    this.reasonFour = false;
                    break;
                case "General":
                    this.reasonOne = false;
                    this.reasonTwo = false;
                    this.reasonThree = false;
                    this.reasonFour = false;
                    this.reasonFive = false;
                    break;
                case "":
                    this.reasonOne = false;
                    this.reasonTwo = false;
                    this.reasonThree = false;
                    this.reasonFour = false;
                    this.reasonFive = false;
                    break;
            }
            //this.leadRecord['Contact_Reason__c'] = event.target.value;
            this.ContactReason = event.target.value;
            this.contactReasonError = false;
            this.isConReasonSelected = false;
        }
    }

    handleIama(event) {
        if (event.target.value == '') {
            this.IamAError = true;
        } else {
           // this.leadRecord['I_am_a__c'] = event.target.value;
            this.IamA = event.target.value;
            this.IamAError = false;
            this.isIAmSelected = false;
        }
    }

    handleDepositType(event) {
        if (event.target.value == '') {
            this.depositTypeError = true;
        } else {
            //this.leadRecord['Deposit_Type__c'] = event.target.value;
            this.DepositType = event.target.value;
            this.depositTypeError = false;
            this.isDepoTypeSelected = false;
        }
    }

    handleCaptcha(event) {
        if (!event.detail.value && (event.detail.response != null && event.detail.response != "" && event.detail.response != undefined)) {
            RecaptchaHandler({
                recaptchaResponse: event.detail.response
            }).then(result => {
                if (result.includes('Success')) {
                    this.showSubmit = true;
                } else {
                    this.showSubmit = false;
                }
                console.log('Result:::', result);
            }).catch(error => {
                this.showSubmit = false;
                console.log('Error while validating Captcha::', JSON.stringify(error));
            })
        } else if (event.detail.value) {
            this.showSubmit = false;
        }
    }

    addressFieldChangeHandler(event) {
        let retunredAddress = event.detail;
        if (retunredAddress.addressType == '') {
            if (retunredAddress.fieldName.includes("TownCity")) {
                this.address = { ...this.address, "Town": retunredAddress.value }

            } else if (retunredAddress.fieldName.includes("County")) {
                this.address = { ...this.address, "County": retunredAddress.value }

            } else if (retunredAddress.fieldName.includes("Postcode")) {
                this.address = { ...this.address, "Postcode": retunredAddress.value }
                var isPostalCodeNI = false;
                this.postalCodesList.forEach(item => {
                    if (retunredAddress.value.includes(item.Label)) {
                        isPostalCodeNI = true;
                    }
                });
                this.isAddressNotNI = !isPostalCodeNI;

                if (this.isAddressNotNI) {
                    //this.showToast();
                    this.isAddressValidError = true;
                    
                } else {
                    this.isAddressValidError = false;
                }
            } else if (retunredAddress.fieldName.includes("Country")) {
                this.address = { ...this.address, "Country": retunredAddress.value }

            } else if (retunredAddress.fieldName.includes("Street")) {
                this.address = { ...this.address, "Street": retunredAddress.value }
            } else if (retunredAddress.fieldName.includes("houseNo")) {
                this.address = { ...this.address, "houseNo": retunredAddress.value }
            } else if (retunredAddress.fieldName.includes("BuildingName")) {
                this.address = { ...this.address, "BuildingName": retunredAddress.value }
            } else if (retunredAddress.fieldName.includes("Locality")) {
                this.address = { ...this.address, "Locality": retunredAddress.value }
            }
        }
        console.log('line 270'+this.address);
        console.log('line 271'+this.address);
        console.log('line 302'+this.address.Postcode);
        console.log('line 303'+this.address.houseNo);
        console.log('line 304'+this.address.Street);
        console.log('line 305'+this.address.BuildingName);
        console.log('line 306'+this.address.Locality);
    }

    selectingAddressHandler(event) {
        let retunredAddress = event.detail;
        if (retunredAddress.addressType == '') {
            this.address = retunredAddress.addressObj;

            var isPostalCodeNI = false;
            this.postalCodesList.forEach(item => {
                if (retunredAddress.addressObj.Postcode.includes(item.Label)) {
                    isPostalCodeNI = true;
                }
            });
            this.isAddressNotNI = !isPostalCodeNI;
        }
        if (this.isAddressNotNI) {
            //this.showToast();
            this.isAddressValidError = true;
            //isValid = false;
        } else {
            this.isAddressValidError = false;
        }
    }

    
    handleKeyPress(event) {
        // Get the character code of the pressed key
        const charCode = event.which || event.keyCode;
    
        // Allow only numbers and alphanumeric characters
        if (!(charCode >= 48 && charCode <= 57) && // Numeric (0-9)
            !(charCode >= 65 && charCode <= 90) && // Uppercase alphabets (A-Z)
            !(charCode >= 97 && charCode <= 122)) { // Lowercase alphabets (a-z)
            event.preventDefault(); // Prevent the character from being entered
        }
    }

    isInputValid() {
        let isValid = true;
        let inputFields = this.template.querySelectorAll(".validate");
        inputFields.forEach(inputField => {
            if (!inputField.checkValidity()) {
                inputField.reportValidity();
                isValid = false;
                //this.showToast();
            }
            this.leadRecord[inputField.name] = inputField.value;
        });
        return isValid;
    }
    
    submitForm() {
        if (/* (this.address.AddressLine != null && this.address.AddressLine != '' && this.address.AddressLine != undefined) && */
            (this.address.County != null || this.address.County != '' || this.address.County != undefined) ||
            (this.address.Postcode != null || this.address.Postcode != '' || this.address.Postcode != undefined) ||
            (this.address.Street != null || this.address.Street != '' || this.address.Street != undefined) ||
            (this.address.Town != null || this.address.Town != '' || this.address.Town != undefined) /* &&
            (this.address.localAuthorityArea != null && this.address.localAuthorityArea != '' && this.address.localAuthorityArea == undefined) */) {
            //this.leadRecord['houseNo'] = this.address.houseNo;
            //this.leadRecord['Address__c'] = this.address.Street;
            //this.leadRecord['Town_City__c'] = this.address.Town;
            //this.leadRecord['Postalcode__c'] = this.address.Postcode;
            //this.leadRecord['Country__c'] = this.address.Country; 
            //this.leadRecord['County__c'] = this.address.County;
            this.houseNo  = this.address.houseNo;
            this.Street  = this.address.Street;
            this.Town  = this.address.Town;
            this.Postalcode   = this.address.Postcode; 
            this.County  = this.address.County;
            this.BuildingName = this.address.BuildingName;
            this.Locality = this.address.Locality;
            console.log('line 402'+this.address.Postcode);
            console.log('line 403'+this.address.houseNo);
            console.log('line 404'+this.address.houseNo);
            console.log('line 405'+this.address.BuildingName);
            console.log('line 406'+this.address.Locality);
            this.isAddressVaild = false;
            
        } 
        if(this.isAddressVaild){
            this.isAddressVaild ? this.isAddressValidError = true : this.isAddressValidError = false;
            this.isValidAdress = false;
        } else if(this.isAddressNotNI){
            this.isAddressValidError = true;
            this.isValidAdress = false;
        } else {
            this.isAddressValidError = false;
            this.isValidAdress = true;
        }
        if (this.isAddressNotNI || this.isConReasonSelected || this.isIAmSelected || this.isDepoTypeSelected) {
            //this.showToast();
            
            this.isConReasonSelected ? this.contactReasonError = true : this.contactReasonError = false;
            this.isIAmSelected ? this.IamAError = true : this.IamAError = false;
            this.isDepoTypeSelected ? this.depositTypeError = true : this.depositTypeError = false;
            this.isInputValid();
        } else if (this.isInputValid() && !this.isAddressNotNI && !this.isConReasonSelected && !this.isIAmSelected && !this.isDepoTypeSelected && this.isValidAdress) {
            this.isAddressValidError = false;
            let name = this.template.querySelector('lightning-input[data-name="yourName"]').value;
            let lastname = this.template.querySelector('lightning-input[data-name="LastName"]').value;
            let Email = this.template.querySelector('lightning-input[data-name="Email"]').value; 
            let depositNumber = this.template.querySelector('lightning-input[data-name="deposit-number"]').value;
            let comments = this.template.querySelector('lightning-textarea[data-name="comments"]').value;
            if (depositNumber != null && depositNumber.trim() != "" && depositNumber != undefined) {
                //this.leadRecord['Certificate_Code_or_Deposit_Account_Numb__c'] = depositNumber;
                this.DAN = depositNumber;
            }
            //this.leadRecord['FirstName'] = name;
            //this.leadRecord['LastName'] = lastname;
            this.FirstName = name;
            this.LastName = lastname;
            this.Email = Email;
            this.YourMsg = comments;
            //console.log('createLead>>>>' + JSON.stringify(this.leadRecord));
            /*createLead({
                "leadRec": this.leadRecord
            }).then(result => {
                console.log('Result is >>>>' + JSON.stringify(result));
                if (result) {
                    this.showThankYou = true;
                }
            }).catch(error => {
                console.log('Error is>>>' + JSON.stringify(error));
            })*/

            console.log('line 381'+this.ContactReason);
            console.log('line 382'+this.FirstName);
            console.log('line 383'+this.LastName);
            console.log('line 384'+this.IamA);
            console.log('line 385'+this.houseNo);
            console.log('line 386'+this.Town);
            console.log('line 387'+this.BuildingName);
            console.log('line 388'+this.Locality);
            sendEmail({
                //"leadRec" : this.leadRecord
                ContactReason : this.ContactReason,
                firstName : this.FirstName,
                lastName : this.LastName,
                IamA : this.IamA,
                Email : this.Email,
                DAN : this.DAN,
                DepositType : this.DepositType,
                Postcode : this.Postalcode,
                houseNo : this.houseNo,
                Street : this.Street,
                Town : this.Town,
                county : this.County,
                BuildingName : this.BuildingName,
                Locality : this.Locality,
                YourMsg : this.YourMsg

            }).then(result => {

                console.log('Send Email Result>>>' + JSON.stringify(result));
                if (result) {
                    this.showThankYou = true;
                }
            }).catch(error => {
                console.log('Error sending email>>>>' + JSON.stringify(error));
            })
        }
    }

    /*showToast() {
        const event = new ShowToastEvent({
            title: 'Only NI postcodes are allwed',
            message: 'You must provide a Northern Ireland Address',
            variant: 'warning',
            mode: 'dismissable'
        });
        this.dispatchEvent(event);
    }*/
}