import { LightningElement, track, wire, api } from 'lwc';
import EWITheme from '@salesforce/resourceUrl/EWITheme';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getclaimdetailsforevidence from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.getclaimdetailsforevidence';
import updateClaimAGLL from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.updateClaimAGLL';
import updateAdditionalComments from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.updateAdditionalComments';

import updateClaimBreakdown from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.updateClaimBreakdown';
import updatekeyDocuments from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.updatekeyDocuments';
import cancelclaimHoldingDisputedAmount from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.cancelclaimHoldingDisputedAmount';
import cancelclaimNotHoldingDisputedAmount from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.cancelclaimNotHoldingDisputedAmount';
import getHelpArticleDocument from '@salesforce/apex/EI_EWI_AGLLEvidenceGathering.getHelpArticleDocument';
import EWIVPlus_Link from '@salesforce/label/c.EWIVPlus_Link';

export default class EI_EWI_Evidence_Gathering_AGLL_ViewOnly_Cmp extends LightningElement {
   ew_arrow_dropleft = EWITheme + '/assets/img/ew-arrow-dropleft.png';
   md_arrow_dropleft = EWITheme + '/assets/img/md-arrow-dropleft.png';
   warning_icon = EWITheme + '/assets/img/warning_icon.png';
   feather_download = EWITheme + '/assets/img/feather-download.svg';
   question_circle = EWITheme + '/assets/img/question-circle.png';

   pound_icon = EWITheme + '/assets/img/pound_icon.png';
   
   @track ClaimsDetails = {isTenantObligationsEviAttachment: false, isInventorycheckEviAttachmentFound: false, isCheckoutReportEviAttachmentFound: false, isRentStatementEviAttachmentFound: false};
   @track evidenceAttachments = [];
   @track disputeItems = [];
   @track currentItem = 0;
   @track ViewContinue = true;
   @track keyDocuments = false;
   @track Isclaimamountexceed = false;
   @track showClaimBreakdown = false;
   @track showClaimBreakdownCleaning = false;
   @track showClaimBreakdownDamage = false;
   @track showClaimBreakdownRedecoration = false;
   @track showClaimBreakdownGardening = false;
   @track showClaimBreakdownRentArrears = false;
   @track showClaimBreakdownOther = false;
   @track showAdditionalComments = false;
   @track showReviewsubmission = false;
   @track showCancelDispute = false;
   @track cancelFromPage = '';
   @track isHoldingDisputedFunds = false;
   @track showDetails = true;

   connectedCallback(){
      const queryString = window.location.search;
      console.log('queryString => ' + queryString);
      const urlParams = new URLSearchParams(queryString);
      console.log('urlParams => ' + urlParams);
      const caseId = urlParams.get('caseId');
      console.log('caseId => ' + caseId);
      const accessCode = urlParams.get('accessCode');
      this.accessCode = accessCode;
      console.log('accessCode => ' + accessCode);
      if(accessCode == null || accessCode == undefined || accessCode == ''){
         this.showDetails = false;   
         return;
      }
      getclaimdetailsforevidence({accessCode: accessCode}).then(result=>{
         if(result.caseParticipants == null){    
            this.showDetails = false;  
            return;
         }
         this.showDetails = true;
         console.log('getclaimdetailsforevidence result => ' + JSON.stringify(result));
         let caseDetails = result.claim; //result[0].claim;
         this.evidenceAttachments = result.evidAttach; //result[0].evidAttach; // caseDetails.Evidence_Attachments__r;
         this.ClaimsDetails['Status'] = caseDetails.Status;
         this.ClaimsDetails['Total_Protected_Amount__c'] = caseDetails.Total_Protected_Amount__c;
         this.isHoldingDisputedFunds = caseDetails.Total_Protected_Amount__c==0?false:true;
         // this.ClaimsDetails['Total_Agreed_Amount__c'] = (caseDetails.Total_Agreed_by_AG_LL__c-caseDetails.Total_Agreed_by_Tenant__c);
         // this.isHoldingDisputedFunds = this.ClaimsDetails.Total_Agreed_Amount__c==0?false:true;
         
         this.ClaimsDetails['Total_Claimed_by_Landlord__c'] = caseDetails.Total_Claimed_by_Landlord__c;
         if(caseDetails.Total_Claimed_by_Landlord__c >= caseDetails.Total_Deposit__c){
               this.Isclaimamountexceed = true;
         }
         else{
               this.Isclaimamountexceed = false;   
         }
         
         this.ClaimsDetails['totalAgreedByAGLL'] = parseFloat(caseDetails.Total_Agreed_by_AG_LL__c).toFixed(2);
         this.ClaimsDetails['totalAgreedByTT'] = parseFloat(caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
         this.ClaimsDetails['remainDisputeAmount'] = parseFloat(caseDetails.Total_Agreed_by_AG_LL__c - caseDetails.Total_Agreed_by_Tenant__c).toFixed(2);
         this.ClaimsDetails['Id'] = caseDetails.Id;
         this.ClaimsDetails['Evidence_Attachments__r'] = caseDetails.Evidence_Attachments__r;
         this.ClaimsDetails['Dispute_Responded_By__c'] = caseDetails.Dispute_Responded_By__c;
         this.ClaimsDetails['Additional_comments_AGLL__c'] = caseDetails.Additional_comments_AGLL__c;
         
         if(caseDetails.Consent_box_AGLL__c =='Yes'){
            this.ClaimsDetails['Consent_box_AGLL__c'] = true;
         }
         else{
            this.ClaimsDetails['Consent_box_AGLL__c'] = false;
         }
         if(caseDetails.Claim_exceed__c =='Yes' || caseDetails.Claim_exceed__c =='No'){
            if(caseDetails.Claim_exceed__c =='Yes'){
               this.ClaimsDetails['claimExceed'] = true;
            }
            else if(caseDetails.Claim_exceed__c =='No'){
               this.ClaimsDetails['claimExceed'] = false;
            }
         }
         this.ClaimsDetails['claimExceedsComment'] = caseDetails.Claim_exceeds_comment_AGLL__c;

         if(caseDetails.Tenant_obligations__c =='Yes' || caseDetails.Tenant_obligations__c =='No'){
            this.ClaimsDetails['isTenantObligationsValue'] = true;
            if(caseDetails.Tenant_obligations__c =='Yes'){
               this.ClaimsDetails['TenantObligations'] = true;
            }
            else if(caseDetails.Tenant_obligations__c =='No'){
               this.ClaimsDetails['TenantObligations'] = false;
            }
         }
         if(caseDetails.inventorycheck_in_report_AGLL__c =='Yes' || caseDetails.inventorycheck_in_report_AGLL__c =='No'){
            this.ClaimsDetails['isInventorycheckValue'] = true;
            if(caseDetails.inventorycheck_in_report_AGLL__c =='Yes'){
               this.ClaimsDetails['inventorycheck'] = true;
            }
            else if(caseDetails.inventorycheck_in_report_AGLL__c =='No'){
               this.ClaimsDetails['inventorycheck'] = false;
            }
         }
         if(caseDetails.check_out_report_AGLL__c =='Yes' || caseDetails.check_out_report_AGLL__c =='No'){
            this.ClaimsDetails['isCheckoutReportValue'] = true;
            if(caseDetails.check_out_report_AGLL__c =='Yes'){
               this.ClaimsDetails['checkoutReport'] = true;
            }
            else if(caseDetails.check_out_report_AGLL__c =='No'){
               this.ClaimsDetails['checkoutReport'] = false;
            }
         }
         if(caseDetails.Rent_statement_AGLL__c =='Yes' || caseDetails.Rent_statement_AGLL__c =='No'){
            this.ClaimsDetails['isRentStatementValue'] = true;
            if(caseDetails.Rent_statement_AGLL__c =='Yes'){
               this.ClaimsDetails['rentStatement'] = true;
            }
            else if(caseDetails.Rent_statement_AGLL__c =='No'){
               this.ClaimsDetails['rentStatement'] = false;
            }
         }
         
         var respondDate = new Date(caseDetails.Respond_Date__c);
         if(respondDate!= null || respondDate!= undefined|| respondDate!= ''){
            var checkdate = respondDate.getDate().toString().padStart(2, "0");;
            var checkmonth = (respondDate.getMonth()+1).toString().padStart(2, "0");
            var checkyear = respondDate.getFullYear();
            var newDate = checkdate +'/'+ checkmonth+'/'+checkyear;
            this.ClaimsDetails['respondDate'] = newDate;
         }
         let disputeItems = [];
         disputeItems.push({key:'Cleaning'});
         disputeItems.push({key:'Damage'});
         disputeItems.push({key:'Redecoration'});
         disputeItems.push({key:'Gardening'});
         disputeItems.push({key:'Rent arrears'});
         disputeItems.push({key:'Other'});
         let claimItems = result.disputeItems; //caseDetails.Dispute_Items__r;
         console.log('disputeItems.length before');
         for(let i=0; i<disputeItems.length; i++){
            console.log('disputeItems.length after');
            let flag = false;
            console.log('claimItems.length before');
               for(let j=0; j<claimItems.length; j++){
            console.log('claimItems.length after');

                  if(disputeItems[i].key.includes(claimItems[j].Type__c)){
                     flag = true;
                     // console.log("claimItems includes => " + claimItems[j].Type__c)
                     // this.disputeItems.push({key:claimItems[j].Type__c, isOther: claimItems[j].Type__c == 'Other'?claimItems[j].Agreed_by_AGLL__c.toFixed(2)+' '+claimItems[j].Other_Reason__c:'',
                     //    requestedByAGLL: claimItems[j].Agreed_by_AGLL__c.toFixed(2), agreedbyTenant: claimItems[j].Agreed_by_Tenant__c, 
                     //    amountInDispute: claimItems[j].Agreed_by_AGLL__c - claimItems[j].Agreed_by_Tenant__c,
                     //    [claimItems[j].Type__c] :true, isShow: j==0?true:false});
                     disputeItems[i]['isOther']= claimItems[j].Type__c == 'Other'?claimItems[j].Agreed_by_AGLL__c.toFixed(2)+'\n'+claimItems[j].Other_Reason__c:'';
                     disputeItems[i]['requestedByAGLL']= claimItems[j].Agreed_by_AGLL__c.toFixed(2);
                     disputeItems[i]['agreedbyTenant']= claimItems[j].Agreed_by_Tenant__c;
                     disputeItems[i]['amountInDispute']= claimItems[j].Agreed_by_AGLL__c - claimItems[j].Agreed_by_Tenant__c;
                     disputeItems[i][claimItems[j].Type__c] =true;
                     disputeItems[i]['isShow']= j==0?true:false;

                     disputeItems[i]['Id']= claimItems[j].Id;

                     disputeItems[i]['Claim_description_for_cleaning_agll__c']= claimItems[j].Claim_description_for_cleaning_agll__c;
                     disputeItems[i]['Supporting_clause_cleaning_agll__c']= claimItems[j].Supporting_clause_cleaning_agll__c;
                     disputeItems[i]['Evidence_at_tenancystart_cleaning_agll__c']= claimItems[j].Evidence_at_tenancystart_cleaning_agll__c;
                     disputeItems[i]['Evidence_at_tenancy_end_for_cleaning_agl__c']= claimItems[j].Evidence_at_tenancy_end_for_cleaning_agl__c;
                     disputeItems[i]['Supporting_evidence_for_cleaning_agll__c']= claimItems[j].Supporting_evidence_for_cleaning_agll__c;

                     disputeItems[i]['Claim_description_for_damage_agll__c']= claimItems[j].Claim_description_for_damage_agll__c;
                     disputeItems[i]['Supporting_clause_damage_agll__c']= claimItems[j].Supporting_clause_damage_agll__c;
                     disputeItems[i]['Evidence_at_tenancystart_damage_agll__c']= claimItems[j].Evidence_at_tenancystart_damage_agll__c;
                     disputeItems[i]['Evidence_at_tenancy_end_for_damage_agll__c']= claimItems[j].Evidence_at_tenancy_end_for_damage_agll__c;
                     disputeItems[i]['Supporting_evidence_for_damage_agll__c']= claimItems[j].Supporting_evidence_for_damage_agll__c;

                     disputeItems[i]['Claim_description_for_redecoration_agll__c']= claimItems[j].Claim_description_for_redecoration_agll__c;
                     disputeItems[i]['Supporting_clause_redecoration_agll__c']= claimItems[j].Supporting_clause_redecoration_agll__c;
                     disputeItems[i]['Evidence_at_tenancystart_redecoration_ag__c']= claimItems[j].Evidence_at_tenancystart_redecoration_ag__c;
                     disputeItems[i]['Evidence_at_tenancyend_redecoration_agll__c']= claimItems[j].Evidence_at_tenancyend_redecoration_agll__c;
                     disputeItems[i]['Supporting_evidence_for_redecoration_agl__c']= claimItems[j].Supporting_evidence_for_redecoration_agl__c;

                     disputeItems[i]['Claim_description_for_gardening_agll__c']= claimItems[j].Claim_description_for_gardening_agll__c;
                     disputeItems[i]['Supporting_clause_gardening_agll__c']= claimItems[j].Supporting_clause_gardening_agll__c;
                     disputeItems[i]['Evidence_at_tenancystart_gardening_agll__c']= claimItems[j].Evidence_at_tenancystart_gardening_agll__c;
                     disputeItems[i]['Evidence_at_tenancyend_gardening_agll__c']= claimItems[j].Evidence_at_tenancyend_gardening_agll__c;
                     disputeItems[i]['Supporting_evidence_for_gardening__c']= claimItems[j].Supporting_evidence_for_gardening__c;

                     disputeItems[i]['Rent_arrears_description_agll__c']= claimItems[j].Rent_arrears_description_agll__c;
                     disputeItems[i]['Was_the_property_re_let_rent_agll__c']= claimItems[j].Was_the_property_re_let_rent_agll__c;
                     disputeItems[i]['Supporting_clause_rent_agll__c']= claimItems[j].Supporting_clause_rent_agll__c;
                     disputeItems[i]['Supporting_evidence_for_rent_agll__c']= claimItems[j].Supporting_evidence_for_rent_agll__c;

                     disputeItems[i]['Claim_breakdown_other_AGLL__c']= claimItems[j].Claim_breakdown_other_AGLL__c;
                     disputeItems[i]['Supporting_clause_other_agll__c']= claimItems[j].Supporting_clause_other_agll__c;
                     disputeItems[i]['Supporting_evidence_for_other_agll__c']= claimItems[j].Supporting_evidence_for_other_agll__c;

                  }
               }
               if(flag == false){
                  disputeItems.splice(i, 1);
                  i--;
               }
         }
         this.disputeItems = disputeItems;
         console.log("disputeItems bsjdhcbjsdhbc=> " + JSON.stringify(this.disputeItems));
      }).catch(error => {
         console.log('getclaimdetailsforevidence error => ' + JSON.stringify(error), error);
      })
      

      console.log("disputeItems => " + JSON.stringify(this.disputeItems));
   }

   renderedCallback(){
      if(this.ClaimsDetails.Consent_box_AGLL__c){
         this.template.querySelector('.consentbox').classList.add('blue_theme');
         this.template.querySelector('.consentbox').classList.remove('disable_ew_btn');
      }else{
         this.template.querySelector('.consentbox').classList.remove('blue_theme');
         this.template.querySelector('.consentbox').classList.add('disable_ew_btn');
      }
   }

   clickYes(event) {  
      let selectRecordId = event.target.title;
      if(selectRecordId.includes('Exceedclaim')){
         // component.set("v.ClaimsDetails[0].Claim_exceed__c",'Yes');
         this.ClaimsDetails['claimExceed'] = true;
         this.template.querySelector('.exceedclaimyes').classList.add('active'); 
         this.template.querySelector('.exceedclaimno').classList.remove('active');
      }
      else if(selectRecordId =='TenantObligations'){
         // component.set("v.ClaimsDetails[0].Tenant_obligations__c",'No');
         this.ClaimsDetails['isTenantObligationsValue'] = true;
         this.ClaimsDetails['TenantObligations'] = true;
         this.template.querySelector('.tenantobligationsyes').classList.add('active'); 
         this.template.querySelector('.tenantobligationsno').classList.remove('active');
      }
      else if(selectRecordId =='inventorycheck'){
         // component.set("v.ClaimsDetails[0].inventorycheck_in_report_AGLL__c",'No');
         this.ClaimsDetails['isInventorycheckValue'] = true;
         this.ClaimsDetails['inventorycheck'] = true;
         this.template.querySelector('.inventorycheckyes').classList.add('active'); 
         this.template.querySelector('.inventorycheckno').classList.remove('active');
      }
      else if(selectRecordId =='checkoutReport'){
         // component.set("v.ClaimsDetails[0].check_out_report_AGLL__c",'No');
         this.ClaimsDetails['isCheckoutReportValue'] = true;
         this.ClaimsDetails['checkoutReport'] = true;
         this.template.querySelector('.checkoutreportyes').classList.add('active'); 
         this.template.querySelector('.checkoutreportno').classList.remove('active');
      }
      else if(selectRecordId =='rentStatement'){
            // component.set("v.ClaimsDetails[0].Rent_statement_AGLL__c",'No');
         this.ClaimsDetails['isRentStatementValue'] = true;
         this.ClaimsDetails['rentStatement'] = true;
         this.template.querySelector('.rentstatementyes').classList.add('active'); 
         this.template.querySelector('.rentstatementno').classList.remove('active');
      }
      // alert('TenantObligations => ' +this.ClaimsDetails.TenantObligations);
      // alert('inventorycheck => ' +this.ClaimsDetails.inventorycheck);
      // alert('checkoutReport => ' +this.ClaimsDetails.checkoutReport);
      // alert('rentStatement => ' +this.ClaimsDetails.rentStatement);
   }
  
   clickNo(event) {  
      let selectRecordId = event.target.title;
      if(selectRecordId =='Exceedclaim') {
         // component.set("v.ClaimsDetails[0].Claim_exceed__c",'No');
         this.ClaimsDetails['claimExceed'] = false;
         this.template.querySelector('.exceedclaimyes').classList.remove('active'); 
         this.template.querySelector('.exceedclaimno').classList.add('active');
         setTimeout(() => {
            if(this.ClaimsDetails['claimExceed']){
               console.log('exceedclaimyes => ' +this.template.querySelector('.exceedclaimyes'));
               this.template.querySelector('.exceedclaimyes').classList.add('active'); 
            }
            else if(!this.ClaimsDetails['claimExceed']){
               console.log('exceedclaimno => ' +this.template.querySelector('.exceedclaimno'));
               this.template.querySelector('.exceedclaimno').classList.add('active'); 
            }
      
            if(this.ClaimsDetails['TenantObligations']){
               console.log('tenantobligationsyes => ' +this.template.querySelector('.tenantobligationsyes'));
               this.template.querySelector('.tenantobligationsyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['TenantObligations'] == false){
               console.log('tenantobligationsno => ' +this.template.querySelector('.tenantobligationsno'));
               this.template.querySelector('.tenantobligationsno').classList.add('active'); 
            }
      
            if(this.ClaimsDetails['inventorycheck']){
               console.log('inventorycheckyes => ' +this.template.querySelector('.inventorycheckyes'));
               this.template.querySelector('.inventorycheckyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['inventorycheck'] == false){
               console.log('inventorycheckno => ' +this.template.querySelector('.inventorycheckno'));
               this.template.querySelector('.inventorycheckno').classList.add('active'); 
            }
            
            if(this.ClaimsDetails['checkoutReport']){
               console.log('checkoutreportyes => ' +this.template.querySelector('.checkoutreportyes'));
               this.template.querySelector('.checkoutreportyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['checkoutReport'] == false){
               console.log('checkoutreportno => ' +this.template.querySelector('.checkoutreportno'));
               this.template.querySelector('.checkoutreportno').classList.add('active'); 
            }
            
            if(this.ClaimsDetails['rentStatement']){
               console.log('rentstatementyes => ' +this.template.querySelector('.rentstatementyes'));
               this.template.querySelector('.rentstatementyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['rentStatement'] == false){
               console.log('rentstatementno => ' +this.template.querySelector('.rentstatementno'));
               this.template.querySelector('.rentstatementno').classList.add('active'); 
            }
         }, 100); 
      }
      else if(selectRecordId =='TenantObligations'){
         // component.set("v.ClaimsDetails[0].Tenant_obligations__c",'No');
         this.ClaimsDetails['isTenantObligationsValue'] = true;
         this.ClaimsDetails['TenantObligations'] = false;
         this.template.querySelector('.tenantobligationsyes').classList.remove('active'); 
         this.template.querySelector('.tenantobligationsno').classList.add('active');

         this.ClaimsDetails.isTenantObligationsEviAttachment = false;
      }
      else if(selectRecordId =='inventorycheck'){
         // component.set("v.ClaimsDetails[0].inventorycheck_in_report_AGLL__c",'No');
         this.ClaimsDetails['isInventorycheckValue'] = true;
         this.ClaimsDetails['inventorycheck'] = false;
         this.template.querySelector('.inventorycheckyes').classList.remove('active'); 
         this.template.querySelector('.inventorycheckno').classList.add('active');

         this.ClaimsDetails.isInventorycheckEviAttachmentFound = false;
      }
      else if(selectRecordId =='checkoutReport'){
         // component.set("v.ClaimsDetails[0].check_out_report_AGLL__c",'No');
         this.ClaimsDetails['isCheckoutReportValue'] = true;
         this.ClaimsDetails['checkoutReport'] = false;
         this.template.querySelector('.checkoutreportyes').classList.remove('active'); 
         this.template.querySelector('.checkoutreportno').classList.add('active');

         this.ClaimsDetails.isCheckoutReportEviAttachmentFound = false;
      }
      else if(selectRecordId =='rentStatement'){
            // component.set("v.ClaimsDetails[0].Rent_statement_AGLL__c",'No');
         this.ClaimsDetails['isRentStatementValue'] = true;
         this.ClaimsDetails['rentStatement'] = false;
         this.template.querySelector('.rentstatementyes').classList.remove('active'); 
         this.template.querySelector('.rentstatementno').classList.add('active');

         this.ClaimsDetails.isRentStatementEviAttachmentFound = false;
      }
      // alert('TenantObligations => ' +this.ClaimsDetails.TenantObligations);
      // alert('inventorycheck => ' +this.ClaimsDetails.inventorycheck);
      // alert('checkoutReport => ' +this.ClaimsDetails.checkoutReport);
      // alert('rentStatement => ' +this.ClaimsDetails.rentStatement);
   }

   handlegotoDepositSummary(){
      window.location.href =  EWIVPlus_Link+this.accessCode;

      // let currentURL = window.location.href;
      // console.log('currentURL => ' + currentURL);
      // let homeURL = currentURL.split('/ewinsured/s');
      // console.log('homeURL => ' + homeURL);
      // let redirectToURL = homeURL[0]+'/ewinsured/s/?accessCode='+this.accessCode;
      // console.log('redirectToURL => ' + redirectToURL);
      // window.location.href = redirectToURL; //"https://espdev2-thedisputeservice.cs80.force.com/ewinsured/s/?accessCode="+this.accessCode;
   }

   handleGoBackStep(event){
      let title = event.target.title;
      if(title == 'viewContinue'){
         this.ViewContinue = true;
         this.keyDocuments = false;
      }
      else if(title == 'keyDocument'){
         this.ViewContinue = false;
         this.keyDocuments = true;
         this.showClaimBreakdown = false;
      }
      else if(title == 'claimBreakdown'){
         this.keyDocuments = false;
         this.showClaimBreakdown = true;
         this.showAdditionalComments = false;
      }
      else if(title == 'additionalComments'){
         this.showClaimBreakdown = false;
         this.showAdditionalComments = true;
         this.showReviewsubmission = false;
      }
   }

   handleCheckConsent(){
      this.ClaimsDetails.Consent_box_AGLL__c = !this.ClaimsDetails.Consent_box_AGLL__c;
      console.log("ClaimsDetails.Consent_box_AGLL__c => " + this.ClaimsDetails.Consent_box_AGLL__c);
      console.log("this.template.querySelector('.consentbox') => " + this.template.querySelector('.consentbox'));

      if(this.ClaimsDetails.Consent_box_AGLL__c){
         this.template.querySelector('.consentbox').classList.add('blue_theme');
         this.template.querySelector('.consentbox').classList.remove('disable_ew_btn');
      }else{
         this.template.querySelector('.consentbox').classList.remove('blue_theme');
         this.template.querySelector('.consentbox').classList.add('disable_ew_btn');
      }
   }

   handlegotokeyDocuments(){
      console.log("ClaimsDetails.Consent_box_AGLL__c => " + this.ClaimsDetails.Consent_box_AGLL__c);
      if(this.ClaimsDetails.Consent_box_AGLL__c){
         this.ViewContinue = false;
         this.keyDocuments = true;
         this.showClaimBreakdown = false;
         setTimeout(() => {
            if(this.Isclaimamountexceed && this.ClaimsDetails['claimExceed']){
               console.log('exceedclaimyes => ' +this.template.querySelector('.exceedclaimyes'));
               this.template.querySelector('.exceedclaimyes').classList.add('active'); 
            }
            else if(this.Isclaimamountexceed && !this.ClaimsDetails['claimExceed']){
               console.log('exceedclaimno => ' +this.template.querySelector('.exceedclaimno'));
               this.template.querySelector('.exceedclaimno').classList.add('active'); 
            }
      
            if(this.ClaimsDetails['TenantObligations']){
               console.log('tenantobligationsyes => ' +this.template.querySelector('.tenantobligationsyes'));
               this.template.querySelector('.tenantobligationsyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['TenantObligations'] == false){
               console.log('tenantobligationsno => ' +this.template.querySelector('.tenantobligationsno'));
               this.template.querySelector('.tenantobligationsno').classList.add('active'); 
            }
      
            if(this.ClaimsDetails['inventorycheck']){
               console.log('inventorycheckyes => ' +this.template.querySelector('.inventorycheckyes'));
               this.template.querySelector('.inventorycheckyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['inventorycheck'] == false){
               console.log('inventorycheckno => ' +this.template.querySelector('.inventorycheckno'));
               this.template.querySelector('.inventorycheckno').classList.add('active'); 
            }
      
            if(this.ClaimsDetails['checkoutReport']){
               console.log('checkoutreportyes => ' +this.template.querySelector('.checkoutreportyes'));
               this.template.querySelector('.checkoutreportyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['checkoutReport'] == false){
               console.log('checkoutreportno => ' +this.template.querySelector('.checkoutreportno'));
               this.template.querySelector('.checkoutreportno').classList.add('active'); 
            }
            
            if(this.ClaimsDetails['rentStatement']){
               console.log('rentstatementyes => ' +this.template.querySelector('.rentstatementyes'));
               this.template.querySelector('.rentstatementyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['rentStatement'] == false){
               console.log('rentstatementno => ' +this.template.querySelector('.rentstatementno'));
               this.template.querySelector('.rentstatementno').classList.add('active'); 
            }
         }, 100); 
      }
   }

   handlegotoshowClaimBreakdown(){
      var isContinue = true;
      if(!this.ClaimsDetails.claimExceed){
         if(this.ClaimsDetails.TenantObligations){
            const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Tenant obligations');
            if(eviAttachment){
               this.ClaimsDetails['isTenantObligationsEviAttachment'] = false;
            }else{
               this.ClaimsDetails['isTenantObligationsEviAttachment'] = true;
               isContinue = false;
            }
         }
         if(this.ClaimsDetails.inventorycheck){
            const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Inventorycheck in report');
            if(eviAttachment){
               this.ClaimsDetails['isInventorycheckEviAttachmentFound'] = false;
            }else{
               this.ClaimsDetails['isInventorycheckEviAttachmentFound'] = true;
               isContinue = false;
            }
         }
         if(this.ClaimsDetails.checkoutReport){
            const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Check out report');
            if(eviAttachment){
               this.ClaimsDetails['isCheckoutReportEviAttachmentFound'] = false;
            }else{
               this.ClaimsDetails['isCheckoutReportEviAttachmentFound'] = true;
               isContinue = false;
            }
         }
         if(this.ClaimsDetails.rentStatement){
            const eviAttachment = this.evidenceAttachments.find(evi => evi.Evidence_Categories__c == 'Rent statement');
            if(eviAttachment){
               this.ClaimsDetails['isRentStatementEviAttachmentFound'] = false;
            }else{
               this.ClaimsDetails['isRentStatementEviAttachmentFound'] = true;
               isContinue = false;
            }
         }
      }
      // alert('handlegotoshowClaimBreakdown isContinue => ' + isContinue);
      if(isContinue == true){
         // alert('this.ClaimsDetails.claimExceedsComment => ' + this.ClaimsDetails.claimExceedsComment)
         this.keyDocuments = false;
         this.showClaimBreakdown = true;
         this.showAdditionalComments = false;
         console.log('handlegotoshowClaimBreakdown end ' + this.showClaimBreakdown);
      }else if(!isContinue){
         // alert('if isContinue False');

         // alert('if isContinue False END => ' + this.ClaimsDetails.claimExceedsComment);
      }
   }
   handleDisputeItemValueChange(event){
      console.log(event.target.value);
      this.disputeItems[this.currentItem][event.target.name] = event.target.value;
      console.log('this.disputeItems[this.currentItem][event.target.name] => ' + this.disputeItems[this.currentItem][event.target.name])
   }
   goToPreviousItem(event){
      console.log('goToPreviousItem currentItem => ' + this.currentItem);
      if(this.currentItem == 0){
         this.showClaimBreakdown = false;
         this.keyDocuments = true;
         setTimeout(() => {
            if(this.ClaimsDetails['claimExceed']){
               console.log('exceedclaimyes => ' +this.template.querySelector('.exceedclaimyes'));
               this.template.querySelector('.exceedclaimyes').classList.add('active'); 
            }
            else if(!this.ClaimsDetails['claimExceed']){
               console.log('exceedclaimno => ' +this.template.querySelector('.exceedclaimno'));
               this.template.querySelector('.exceedclaimno').classList.add('active'); 
            }
      
            if(this.ClaimsDetails['TenantObligations']){
               console.log('tenantobligationsyes => ' +this.template.querySelector('.tenantobligationsyes'));
               this.template.querySelector('.tenantobligationsyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['TenantObligations'] == false){
               console.log('tenantobligationsno => ' +this.template.querySelector('.tenantobligationsno'));
               this.template.querySelector('.tenantobligationsno').classList.add('active'); 
            }
      
            if(this.ClaimsDetails['inventorycheck']){
               console.log('inventorycheckyes => ' +this.template.querySelector('.inventorycheckyes'));
               this.template.querySelector('.inventorycheckyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['inventorycheck'] == false){
               console.log('inventorycheckno => ' +this.template.querySelector('.inventorycheckno'));
               this.template.querySelector('.inventorycheckno').classList.add('active'); 
            }
            
            if(this.ClaimsDetails['checkoutReport']){
               console.log('checkoutreportyes => ' +this.template.querySelector('.checkoutreportyes'));
               this.template.querySelector('.checkoutreportyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['checkoutReport'] == false){
               console.log('checkoutreportno => ' +this.template.querySelector('.checkoutreportno'));
               this.template.querySelector('.checkoutreportno').classList.add('active'); 
            }
            
            if(this.ClaimsDetails['rentStatement']){
               console.log('rentstatementyes => ' +this.template.querySelector('.rentstatementyes'));
               this.template.querySelector('.rentstatementyes').classList.add('active'); 
            }
            else if(this.ClaimsDetails['rentStatement'] == false){
               console.log('rentstatementno => ' +this.template.querySelector('.rentstatementno'));
               this.template.querySelector('.rentstatementno').classList.add('active'); 
            }
         }, 100); 
      }else{
         this.currentItem--;
         this.disputeItems[this.currentItem].isShow = true;
         this.disputeItems[this.currentItem+1].isShow = false;
      }
   }
   goToNextItem(event){
      var isValid = true;
      let calimItems = [];
      console.log('this.disputeItems[this.currentItem].key => ' + this.disputeItems[this.currentItem].key)
      if(this.disputeItems[this.currentItem].key == 'Cleaning'){
         console.log('this.currentItem => '+this.currentItem)
         console.log(this.disputeItems[this.currentItem].Claim_description_for_cleaning_agll__c);
         if(!this.disputeItems[this.currentItem].Claim_description_for_cleaning_agll__c){
            isValid = false;
         }
         console.log(this.disputeItems[this.currentItem].Supporting_clause_cleaning_agll__c);
         if(!this.disputeItems[this.currentItem].Supporting_clause_cleaning_agll__c){
            isValid = false;
         }
         console.log(this.disputeItems[this.currentItem].Evidence_at_tenancystart_cleaning_agll__c);
         if(!this.disputeItems[this.currentItem].Evidence_at_tenancystart_cleaning_agll__c){
            isValid = false;
         }
         console.log(this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_cleaning_agl__c);
         if(!this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_cleaning_agl__c){
            isValid = false;
         }
         console.log(this.disputeItems[this.currentItem].Supporting_evidence_for_cleaning_agll__c);
         if(!this.disputeItems[this.currentItem].Supporting_evidence_for_cleaning_agll__c){
            isValid = false;
         }
      }else if(this.disputeItems[this.currentItem].key == 'Damage'){
         isValid = this.disputeItems[this.currentItem].Claim_description_for_damage_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_clause_damage_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Evidence_at_tenancystart_damage_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Evidence_at_tenancy_end_for_damage_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_evidence_for_damage_agll__c ? isValid : false;
      }else if(this.disputeItems[this.currentItem].key == 'Redecoration'){
         isValid = this.disputeItems[this.currentItem].Claim_description_for_redecoration_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_clause_redecoration_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Evidence_at_tenancystart_redecoration_ag__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Evidence_at_tenancyend_redecoration_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_evidence_for_redecoration_agl__c ? isValid : false;
      }else if(this.disputeItems[this.currentItem].key == 'Gardening'){
         isValid = this.disputeItems[this.currentItem].Claim_description_for_gardening_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_clause_gardening_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Evidence_at_tenancystart_gardening_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Evidence_at_tenancyend_gardening_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_evidence_for_gardening__c ? isValid : false;
      }else if(this.disputeItems[this.currentItem].key == 'Rent arrears'){
         isValid = this.disputeItems[this.currentItem].Rent_arrears_description_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Was_the_property_re_let_rent_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_clause_rent_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_evidence_for_rent_agll__c ? isValid : false;
      }else if(this.disputeItems[this.currentItem].key == 'Other'){
         isValid = this.disputeItems[this.currentItem].Claim_breakdown_other_AGLL__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_clause_other_agll__c ? isValid : false;
         isValid = this.disputeItems[this.currentItem].Supporting_evidence_for_other_agll__c ? isValid : false;
      }
      
      // alert('isValid => ' + isValid);
      if(isValid){
         // alert('if is valid true => ' + isValid);
         for(let i in this.disputeItems){
            let claim={'Id': this.disputeItems[i].Id,
               'Claim_description_for_cleaning_agll__c': this.disputeItems[i].Claim_description_for_cleaning_agll__c,
               'Supporting_clause_cleaning_agll__c': this.disputeItems[i].Supporting_clause_cleaning_agll__c,
               'Evidence_at_tenancystart_cleaning_agll__c': this.disputeItems[i].Evidence_at_tenancystart_cleaning_agll__c,
               'Evidence_at_tenancy_end_for_cleaning_agl__c': this.disputeItems[i].Evidence_at_tenancy_end_for_cleaning_agl__c,
               'Supporting_evidence_for_cleaning_agll__c': this.disputeItems[i].Supporting_evidence_for_cleaning_agll__c,
            
               'Claim_description_for_damage_agll__c': this.disputeItems[i].Claim_description_for_damage_agll__c,
               'Supporting_clause_damage_agll__c': this.disputeItems[i].Supporting_clause_damage_agll__c,
               'Evidence_at_tenancystart_damage_agll__c': this.disputeItems[i].Evidence_at_tenancystart_damage_agll__c,
               'Evidence_at_tenancy_end_for_damage_agll__c': this.disputeItems[i].Evidence_at_tenancy_end_for_damage_agll__c,
               'Supporting_evidence_for_damage_agll__c': this.disputeItems[i].Supporting_evidence_for_damage_agll__c,

               'Claim_description_for_redecoration_agll__c': this.disputeItems[i].Claim_description_for_redecoration_agll__c,
               'Supporting_clause_redecoration_agll__c': this.disputeItems[i].Supporting_clause_redecoration_agll__c,
               'Evidence_at_tenancystart_redecoration_ag__c': this.disputeItems[i].Evidence_at_tenancystart_redecoration_ag__c,
               'Evidence_at_tenancyend_redecoration_agll__c': this.disputeItems[i].Evidence_at_tenancyend_redecoration_agll__c,
               'Supporting_evidence_for_redecoration_agl__c': this.disputeItems[i].Supporting_evidence_for_redecoration_agl__c,

               'Claim_description_for_gardening_agll__c': this.disputeItems[i].Claim_description_for_gardening_agll__c,
               'Supporting_clause_gardening_agll__c': this.disputeItems[i].Supporting_clause_gardening_agll__c,
               'Evidence_at_tenancystart_gardening_agll__c': this.disputeItems[i].Evidence_at_tenancystart_gardening_agll__c,
               'Evidence_at_tenancyend_gardening_agll__c': this.disputeItems[i].Evidence_at_tenancyend_gardening_agll__c,
               'Supporting_evidence_for_gardening__c': this.disputeItems[i].Supporting_evidence_for_gardening__c,

               'Rent_arrears_description_agll__c': this.disputeItems[i].Rent_arrears_description_agll__c,
               'Was_the_property_re_let_rent_agll__c': this.disputeItems[i].Was_the_property_re_let_rent_agll__c,
               'Supporting_clause_rent_agll__c': this.disputeItems[i].Supporting_clause_rent_agll__c,
               'Supporting_evidence_for_rent_agll__c': this.disputeItems[i].Supporting_evidence_for_rent_agll__c,

               'Claim_breakdown_other_AGLL__c': this.disputeItems[i].Claim_breakdown_other_AGLL__c,
               'Supporting_clause_other_agll__c': this.disputeItems[i].Supporting_clause_other_agll__c,
               'Supporting_evidence_for_other_agll__c': this.disputeItems[i].Supporting_evidence_for_other_agll__c
            };
            calimItems.push(claim);
         }
         // alert('JSON.stringify(calimItems) => ' + JSON.stringify(calimItems));
         
         var totalItem = this.disputeItems.length;
         // alert('goToNextItem totalItem => ' + totalItem);
         // alert('goToNextItem currentItem => ' + this.currentItem);
         if(this.currentItem == totalItem-1){
            this.showClaimBreakdown = false;
            this.showAdditionalComments = true;
         }else {
            this.disputeItems[this.currentItem].isShow = false;
            this.disputeItems[this.currentItem+1].isShow = true;
            this.currentItem++;
         }
      }else if(!isValid){
         // alert('isValid is not true');
      }
   }
   xyznamesmethod(){
      // alert('method called')
   }
   // handlegotoshowClaimBreakdownCleaning(event){
   //    this.keyDocuments = false;
   //    this.showClaimBreakdownCleaning = true;
   //    this.showClaimBreakdownDamage = false;
   // }
   // handlegotoshowClaimBreakdownDamage(event){
   //    this.showClaimBreakdownCleaning = false;
   //    this.showClaimBreakdownDamage = true;
   //    this.showClaimBreakdownRedecoration = false;
   // }
   // handlegotoshowClaimBreakdownRedecoration(event){
   //    this.showClaimBreakdownDamage = false;
   //    this.showClaimBreakdownRedecoration = true;
   //    this.showClaimBreakdownGardening = false;
   // }
   // handlegotoshowClaimBreakdownGardening(event){
   //    this.showClaimBreakdownRedecoration = false;
   //    this.showClaimBreakdownGardening = true;
   //    this.showClaimBreakdownRentArrears = false;
   // }
   // handlegotoshowClaimBreakdownRentArrears(event){
   //    this.showClaimBreakdownGardening = false;
   //    this.showClaimBreakdownRentArrears = true;
   //    this.showClaimBreakdownOther = false;
   // }
   // handlegotoshowClaimBreakdownOther(event){
   //    this.showClaimBreakdownRentArrears = false;
   //    this.showClaimBreakdownOther = true;
   //    this.showAdditionalComments = false;
   // }

   handleClaimsDetailsValuesChange(event){
      console.log(event.target.value);
      this.ClaimsDetails[event.target.name] = event.target.value;
   }
   handlegotoshowReviewsubmission(){
      // alert('this.ClaimsDetails.Additional_comments_AGLL__c => ' + this.ClaimsDetails.Additional_comments_AGLL__c);
      if(this.ClaimsDetails.Status == 'Evidence gathering agent/landlord'){
         // alert('if true' + this.ClaimsDetails.respondDate);
         this.showAdditionalComments = false;
         this.showReviewsubmission = true;
      }else{
         // alert('else => ' + this.accessCode);
         this.handlegotoDepositSummary();
      }
   }

   handleChangeEviAttachmentList(event){
         console.log( 'Value from Child LWC is ' + JSON.stringify(event.detail) );
         var attachmensts = [];
         if(event.detail.type == 'upload'){
            // alert("upload file type" + attachmensts.length);
            let aviAttachment = event.detail.evidanceAttachment;
            attachmensts = [...this.evidenceAttachments, aviAttachment];
            //attachmensts.push(aviAttachment);
            
            // alert("push attachment" + attachmensts.length);
            this.evidenceAttachments = attachmensts;
            // alert("Add again attachemnt");
         }else if(event.detail.type == 'delete'){
            console.log('event.detail.deletedAttachment.Id => ' + event.detail.deletedAttachment.Id);
            for(let index in this.evidenceAttachments){
               console.log('this.evidenceAttachments[index].Id => ' + this.evidenceAttachments[index].Id);
               
               if(this.evidenceAttachments[index].Id != event.detail.deletedAttachment.Id){
                  attachmensts.push(this.evidenceAttachments[index]);
               }
            }
            this.evidenceAttachments = attachmensts;
         }
         console.log('this.evidenceAttachments after => '+ JSON.stringify(this.evidenceAttachments));

   }

   getHelpArticleDocument(){
      //alert("call get guide doc");
      window.open('https://ewinsureddev.blob.core.windows.net/ewinsureddev/5003G000008RH95QAG-1670487092870-TDS%20Help%20Article_v2.pdf?sp=rw&st=2022-04-05T08:51:01Z&se=2032-04-05T16:51:01Z&spr=https&sv=2020-08-04&sr=c&sig=vbBtrfu%2BbFNQQp1SY8AZ3kTf2z9MKp%2F3Hnia3FLKKCg%3D', 
                    '_blank');
      // getHelpArticleDocument().then(result=>{
      //    console.log('result => ' + result)
      //    var res = result;
      //    console.log("Guidance document Id => " + res);
      //    window.open("https://thedisputeservice--fullcopy.sandbox.file.force.com/servlet/servlet.FileDownload?file="+res);
      //    // window.open("/servlet/servlet.FileDownload?file="+res); 
      // }).catch(error=>{
      //    consol.log('error => ' + error);
      // });
   }
}